using MFBot.Languages;

namespace MFBot.Data;

/// <summary>
/// Botun doğuştan bildikleri.
///
/// Tohum cümleler, hazır kalıplar ve küfür kökleri artık DİL PAKETLERİNDE
/// (<see cref="MFBot.Languages.LangPack"/>) — üç dilin içeriği tek dosyada
/// birikmesin diye. Burada sadece dilden bağımsız şeyler kaldı.
/// </summary>
public static class SeedData
{
    /// <summary>Bütün dillerin küfür kökleri. Dil tespiti şaşsa bile küfür kaçmasın.</summary>
    public static string[] ProfanityStems => LangPacks.AllProfanityStems;

    /// <summary>Data/blocklist.txt yoksa oluşturulacak varsayılan içerik.</summary>
    public const string DefaultBlocklistFile =
        """
        # MotherFuckerBot — ek yasak terim listesi
        #
        # Buraya yazdığın her terim: bot tarafından ÖĞRENİLMEZ ve AĞZINDAN ÇIKMAZ.
        # Satır başına bir terim. # ile başlayan satırlar yorumdur.
        # Üç dilde de (Türkçe / İngilizce / Arapça) aynı anda geçerlidir.
        #
        # Kodun içinde zaten şunlar engelli:
        #   - ırk / etnik köken / milliyet hedefli hakaretler
        #   - din ve mezhep hedefli nefret dili
        #   - cinsel yönelim ve cinsel kimlik hedefli hakaretler
        #   - engellilik hedefli hakaretler
        #   - reşit olmayanlarla ilgili cinsel içerik
        #
        # Genel küfür engellenmiyor, botun tüm olayı o.
        #
        # Örnek (# işaretini kaldırıp kullan):
        # patronumun_adi
        # sirket_adi
        """;
}

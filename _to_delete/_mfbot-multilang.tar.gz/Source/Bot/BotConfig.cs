using System.Text.Encodings.Web;
using System.Text.Json;
using MFBot.Languages;

namespace MFBot.Bot;

/// <summary>
/// Ayarlar. Data/config.json dosyasından okunur, yoksa varsayılanlarla oluşturulur.
/// </summary>
public sealed class BotConfig
{
    /// <summary>Botun kendine taktığı isim.</summary>
    public string BotName { get; set; } = "MotherFucker";

    /// <summary>
    /// Mesajın dilini otomatik tespit et. Kapatırsan bot her şeye
    /// <see cref="DefaultLanguage"/> dilinde cevap verir.
    /// </summary>
    public bool AutoDetectLanguage { get; set; } = true;

    /// <summary>
    /// Dil tespiti kararsız kaldığında (tek kelime, sadece sayı) kullanılacak dil:
    /// "tr", "en" ya da "ar".
    /// </summary>
    public string DefaultLanguage { get; set; } = "tr";

    /// <summary><see cref="DefaultLanguage"/> alanının çözümlenmiş hâli.</summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public Lang Language
    {
        get => LangInfo.Parse(DefaultLanguage, Lang.Tr);
        set => DefaultLanguage = value.Code();
    }

    /// <summary>0-10. Tabana eklenen küfür şiddeti. 0 bile tam temiz değil, uyarayım.</summary>
    public int Toxicity { get; set; } = 7;

    /// <summary>Öğrenme açık mı. Kapatırsan bot aptal kalır ama saldırganlığı sürer.</summary>
    public bool LearningEnabled { get; set; } = true;

    /// <summary>Markov cümlesi karıştırma olasılığının tavanı (%). Olgunlukla çarpılır.</summary>
    public int BabbleChance { get; set; } = 45;

    /// <summary>Yeni kelime öğrendiğinde bunu yüzüne vurma olasılığı (%).</summary>
    public int BragChance { get; set; } = 18;

    /// <summary>Kaç mesajda bir beyin diske yazılsın.</summary>
    public int AutoSaveEvery { get; set; } = 10;

    /// <summary>Veri klasörü (beyin, ayar, kara liste).</summary>
    public string DataDirectory { get; set; } = "Data";

    /// <summary>Konsolda ne öğrendiğini göstersin mi.</summary>
    public bool ShowLearningLog { get; set; } = true;

    /// <summary>Tekrarlanabilir çıktı için sabit tohum. 0 = rastgele.</summary>
    public int RandomSeed { get; set; }

    public string BrainPath => Path.Combine(DataDirectory, "brain.json");
    public string BlocklistPath => Path.Combine(DataDirectory, "blocklist.txt");
    public static string ConfigPath(string dataDirectory) => Path.Combine(dataDirectory, "config.json");

    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    public static BotConfig Load(string dataDirectory)
    {
        var path = ConfigPath(dataDirectory);

        try
        {
            if (File.Exists(path))
            {
                var loaded = JsonSerializer.Deserialize<BotConfig>(File.ReadAllText(path), Options);
                if (loaded is not null)
                {
                    loaded.DataDirectory = dataDirectory;
                    return loaded;
                }
            }
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[ayar] config.json okunamadı ({ex.Message}), varsayılanlar kullanılıyor.");
        }

        var config = new BotConfig { DataDirectory = dataDirectory };
        config.Save();
        return config;
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(DataDirectory);
            File.WriteAllText(ConfigPath(DataDirectory), JsonSerializer.Serialize(this, Options));
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[ayar] kaydedilemedi: {ex.Message}");
        }
    }
}

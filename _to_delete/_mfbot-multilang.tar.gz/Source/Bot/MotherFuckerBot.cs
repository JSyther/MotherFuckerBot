using MFBot.Brain;
using MFBot.Data;
using MFBot.Languages;
using MFBot.Response;

namespace MFBot.Bot;

public sealed record BotReply(string Text, LearnReport Learning, IntentResult Intent)
{
    /// <summary>Cevabın verildiği dil — mesajın dili.</summary>
    public Lang Lang => Intent.Lang;
}

/// <summary>
/// Botun dış kapısı. Platformdan bağımsız: konsol da, başka bir arayüz de
/// sadece <see cref="Respond"/> çağırır.
///
/// Dil tespiti burada yapılır ve cevap üretiminin tamamına o dil taşınır.
/// </summary>
public sealed class MotherFuckerBot
{
    private readonly BotConfig _config;
    private readonly BotBrain _brain;
    private readonly ResponseEngine _engine;
    private readonly Random _rng;

    private int _messagesSinceSave;

    public BotConfig Config => _config;
    public BotBrain Brain => _brain;

    /// <summary>
    /// Dil tespitini kapatıp sabit bir dile kilitler. null = otomatik tespit.
    /// Konsoldaki <c>/dil</c> komutu bunu ayarlar.
    /// </summary>
    public Lang? ForcedLang { get; set; }

    public MotherFuckerBot(BotConfig config)
    {
        _config = config;
        _rng = config.RandomSeed == 0 ? new Random() : new Random(config.RandomSeed);

        Directory.CreateDirectory(config.DataDirectory);
        EnsureBlocklistFile();

        var guard = new ContentGuard();
        guard.LoadExtra(config.BlocklistPath);

        var snapshot = MemoryStore.Load(config.BrainPath);

        _brain = new BotBrain(snapshot, guard, _rng);
        _brain.SeedIfEmpty();

        _engine = new ResponseEngine(_rng, _brain, config);

        if (!config.AutoDetectLanguage) ForcedLang = config.Language;
    }

    /// <summary>Mesajı işle: dili anla, önce öğren, sonra AYNI DİLDE cevabı yapıştır.</summary>
    public BotReply Respond(string user, string message)
    {
        var lang = ResolveLang(user, message);
        var intent = IntentDetector.Detect(message, lang);

        var learning = _config.LearningEnabled
            ? _brain.Observe(user, message, lang)
            : new LearnReport { Verdict = _brain.Guard.Inspect(message), Lang = lang };

        var text = _engine.Compose(user, message, intent, learning);

        _messagesSinceSave++;
        if (_messagesSinceSave >= _config.AutoSaveEvery)
        {
            Save();
            _messagesSinceSave = 0;
        }

        return new BotReply(text, learning, intent);
    }

    /// <summary>
    /// Mesajın dilini belirler.
    ///
    /// Kararsız kalınırsa (tek kelime, sadece sayı, emoji) kullanıcının son
    /// konuştuğu dile düşülür. Sohbetin ortasında "ok" yazınca botun dil
    /// değiştirmesi, yanlış dil tahmininden daha rahatsız edici.
    /// </summary>
    public Lang ResolveLang(string user, string message)
    {
        if (ForcedLang is { } forced) return forced;

        var profile = _brain.GetProfile(user);
        var fallback = profile.PreferredLang(_config.Language);

        return LanguageDetector.Detect(message, fallback);
    }

    /// <summary>"Şunu deyince şöyle de" öğretir. Kalıp, tetiğin diline yazılır.</summary>
    public bool Teach(string user, string trigger, string response)
    {
        if (string.IsNullOrWhiteSpace(trigger) || string.IsNullOrWhiteSpace(response)) return false;

        // Öğretilen cevap da süzgeçten geçer, kimse botu nefret makinesine çeviremesin
        if (!_brain.Guard.IsSafeToSay(response) || !_brain.Guard.IsSafeToSay(trigger)) return false;

        var lang = ForcedLang ?? LanguageDetector.Detect(trigger, LanguageDetector.Detect(response, _config.Language));

        _brain.Patterns.Teach(trigger, response, user, lang);

        // Öğretilen cevabı Markov'a da bas, üslubu kapsın
        var tokens = Tokenizer.Tokenize(response, lang);
        if (tokens.Count >= 2) _brain.Markov(lang).Learn(tokens);

        return true;
    }

    public bool Forget(string trigger) => _brain.Patterns.Forget(trigger);

    /// <summary>Bir metin dosyasını toptan öğretir. Beyni hızlı büyütmek için.</summary>
    public (int lines, int learned, int skipped) FeedFile(string path, string user)
    {
        if (!File.Exists(path)) return (0, 0, 0);

        var lines = File.ReadAllLines(path);
        var learned = 0;
        var skipped = 0;

        // Dosya karışık dilli olabilir — satır satır tespit edilir, önceki satır yedek olur
        var lastLang = _config.Language;

        foreach (var line in lines)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;

            var lang = ForcedLang ?? LanguageDetector.Detect(line, lastLang);
            lastLang = lang;

            var report = _brain.Observe(user, line, lang);
            if (report.Verdict == GuardVerdict.Clean && report.SentencesLearned > 0) learned++;
            else skipped++;
        }

        Save();
        return (lines.Length, learned, skipped);
    }

    public void Save()
    {
        _brain.Compact();
        MemoryStore.Save(_brain.State, _config.BrainPath);
    }

    public void Reset()
    {
        _brain.Reset();
        Save();
    }

    public long BrainFileSize() => MemoryStore.FileSize(_config.BrainPath);

    private void EnsureBlocklistFile()
    {
        if (File.Exists(_config.BlocklistPath)) return;

        try
        {
            File.WriteAllText(_config.BlocklistPath, SeedData.DefaultBlocklistFile);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[güvenlik] blocklist.txt oluşturulamadı: {ex.Message}");
        }
    }
}

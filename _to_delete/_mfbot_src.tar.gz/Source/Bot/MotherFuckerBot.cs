using MFBot.Brain;
using MFBot.Data;
using MFBot.Response;

namespace MFBot.Bot;

public sealed record BotReply(string Text, LearnReport Learning, IntentResult Intent);

/// <summary>
/// Botun dış kapısı. Platformdan bağımsız: konsol da, başka bir arayüz de
/// sadece <see cref="Respond"/> çağırır.
/// </summary>
public sealed class MotherFuckerBot
{
    private readonly BotConfig _config;
    private readonly BotBrain _brain;
    private readonly ResponseEngine _engine;
    private readonly Random _rng;

    private int _messagesSinceSave;

    public BotConfig Config => _config;
    public BotBrain Brain => _brain;

    public MotherFuckerBot(BotConfig config)
    {
        _config = config;
        _rng = config.RandomSeed == 0 ? new Random() : new Random(config.RandomSeed);

        Directory.CreateDirectory(config.DataDirectory);
        EnsureBlocklistFile();

        var guard = new ContentGuard();
        guard.LoadExtra(config.BlocklistPath);

        var snapshot = MemoryStore.Load(config.BrainPath);

        _brain = new BotBrain(snapshot, guard, _rng);
        _brain.SeedIfEmpty();

        _engine = new ResponseEngine(_rng, _brain, config);
    }

    /// <summary>Mesajı işle: önce öğren, sonra cevabı yapıştır.</summary>
    public BotReply Respond(string user, string message)
    {
        var intent = IntentDetector.Detect(message);

        var learning = _config.LearningEnabled
            ? _brain.Observe(user, message)
            : new LearnReport { Verdict = _brain.Guard.Inspect(message) };

        var text = _engine.Compose(user, message, intent, learning);

        _messagesSinceSave++;
        if (_messagesSinceSave >= _config.AutoSaveEvery)
        {
            Save();
            _messagesSinceSave = 0;
        }

        return new BotReply(text, learning, intent);
    }

    /// <summary>"Şunu deyince şöyle de" öğretir.</summary>
    public bool Teach(string user, string trigger, string response)
    {
        if (string.IsNullOrWhiteSpace(trigger) || string.IsNullOrWhiteSpace(response)) return false;

        // Öğretilen cevap da süzgeçten geçer, kimse botu nefret makinesine çeviremesin
        if (!_brain.Guard.IsSafeToSay(response) || !_brain.Guard.IsSafeToSay(trigger)) return false;

        _brain.Patterns.Teach(trigger, response, user);

        // Öğretilen cevabı Markov'a da bas, üslubu kapsın
        var tokens = Tokenizer.Tokenize(response);
        if (tokens.Count >= 2) _brain.Markov.Learn(tokens);

        return true;
    }

    public bool Forget(string trigger) => _brain.Patterns.Forget(trigger);

    /// <summary>Bir metin dosyasını toptan öğretir. Beyni hızlı büyütmek için.</summary>
    public (int lines, int learned, int skipped) FeedFile(string path, string user)
    {
        if (!File.Exists(path)) return (0, 0, 0);

        var lines = File.ReadAllLines(path);
        var learned = 0;
        var skipped = 0;

        foreach (var line in lines)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;

            var report = _brain.Observe(user, line);
            if (report.Verdict == GuardVerdict.Clean && report.SentencesLearned > 0) learned++;
            else skipped++;
        }

        Save();
        return (lines.Length, learned, skipped);
    }

    public void Save()
    {
        _brain.Compact();
        MemoryStore.Save(_brain.State, _config.BrainPath);
    }

    public void Reset()
    {
        _brain.Reset();
        Save();
    }

    public long BrainFileSize() => MemoryStore.FileSize(_config.BrainPath);

    private void EnsureBlocklistFile()
    {
        if (File.Exists(_config.BlocklistPath)) return;

        try
        {
            File.WriteAllText(_config.BlocklistPath, SeedData.DefaultBlocklistFile);
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine($"[güvenlik] blocklist.txt oluşturulamadı: {ex.Message}");
        }
    }
}

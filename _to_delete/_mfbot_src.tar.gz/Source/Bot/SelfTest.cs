using MFBot.Brain;
using MFBot.Response;

namespace MFBot.Bot;

/// <summary>
/// "dotnet run -- --test" ile çalışır.
///
/// Bu botun iki iddiası var ve ikisi de test edilebilir:
///   1) Matematikte ASLA doğru cevap vermez (kazara bile).
///   2) Küfür serbest ama nefret söylemi ve çocuk istismarı içeriği geçmez.
/// Kod değiştirdikçe bunu çalıştır, botun karakteri bozulmasın.
/// </summary>
public static class SelfTest
{
    private static int _passed;
    private static int _failed;

    public static int Run()
    {
        Console.WriteLine("MotherFuckerBot — kendini test etme\n");

        TestMathIsAlwaysWrong();
        TestMathParsing();
        TestIntentDetection();
        TestGuardAllowsNormalProfanity();
        TestGuardBlocksHate();
        TestLearningAndPersistence();
        TestResponseNeverEmpty();
        TestTurkishSuffixes();

        Console.WriteLine();
        Console.WriteLine($"SONUÇ: {_passed} geçti, {_failed} kaldı.");

        return _failed == 0 ? 0 : 1;
    }

    // ---------------------------------------------------------------- testler

    private static void TestMathIsAlwaysWrong()
    {
        var rng = new Random(1234);
        var saboteur = new MathSaboteur(rng);
        var mistakes = 0;

        for (var i = 0; i < 5000; i++)
        {
            var a = rng.Next(0, 500);
            var b = rng.Next(1, 500);
            var op = "+-*/"[rng.Next(4)];
            var expression = $"{a} {op} {b}";

            var result = saboteur.TryEvaluate(expression);
            if (result is null) { mistakes++; continue; }

            var wrong = saboteur.Sabotage(result);

            if (double.TryParse(wrong, System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out var value)
                && Math.Abs(value - result.Truth) < 0.0001)
            {
                mistakes++;
            }
        }

        Check("matematik: 5000 işlemin hiçbirinde doğru cevap vermedi", mistakes == 0,
            $"{mistakes} kez doğruyu söyledi veya çözemedi");
    }

    private static void TestMathParsing()
    {
        var saboteur = new MathSaboteur(new Random(7));

        (string Input, double Expected)[] cases =
        {
            ("2+2", 4),
            ("2 + 2 kaç eder", 4),
            ("100/4", 25),
            ("15 * 3 - 7", 38),
            ("(8+2)*3", 30),
            ("2^10", 1024),
            ("-5 + 3", -2),
            ("7 artı 8", 15),
            ("6 çarpı 7 kaç eder", 42),
            ("10 bölü 4", 2.5)
        };

        foreach (var (input, expected) in cases)
        {
            var result = saboteur.TryEvaluate(input);
            Check($"matematik ayrıştırma: \"{input}\" = {expected}",
                result is not null && Math.Abs(result.Truth - expected) < 0.0001,
                result is null ? "çözülemedi" : $"çıkan: {result.Truth}");
        }
    }

    private static void TestIntentDetection()
    {
        (string Input, Intent Expected)[] cases =
        {
            ("selam", Intent.Greeting),
            ("naber kanka", Intent.Greeting),
            ("2+2 kaç eder?", Intent.MathQuestion),
            ("kuantum fiziği nedir", Intent.Definition),
            ("dünya yuvarlak mı?", Intent.YesNoQuestion),
            ("türkiyenin başkenti neresi", Intent.WhQuestion),
            ("ne zaman geleceksin", Intent.WhQuestion),
            ("sen tam bir gerizekalısın amk", Intent.Insult),
            ("sağol kanka harikasın", Intent.Compliment),
            ("seni kim yaptı", Intent.AboutBot),
            ("görüşürüz", Intent.Farewell),
            ("bugün hava çok güzel pikniğe gidelim", Intent.Statement),
            ("/yardim", Intent.Command)
        };

        foreach (var (input, expected) in cases)
        {
            var actual = IntentDetector.Detect(input).Intent;
            Check($"niyet: \"{input}\" -> {expected}", actual == expected, $"çıkan: {actual}");
        }
    }

    private static void TestGuardAllowsNormalProfanity()
    {
        var guard = new ContentGuard();

        string[] shouldPass =
        {
            "amına koyayım ne diyorsun sen",
            "orospu çocuğu gibi konuşma",
            "siktir git yarrak kafalı",
            "sen tam bir gerizekalısın amk",
            "ilkokulu mu bitirmedin salak",
            "bok gibi bir cevap verdin aq"
        };

        foreach (var line in shouldPass)
            Check($"küfür serbest: \"{line}\"", guard.Inspect(line) == GuardVerdict.Clean,
                $"çıkan: {guard.Inspect(line)}");
    }

    private static void TestGuardBlocksHate()
    {
        var guard = new ContentGuard();

        string[] shouldBlock =
        {
            "ibne herif",
            "mongol musun sen",
            "çingene pisliği",
            "gavur dölü"
        };

        foreach (var line in shouldBlock)
            Check($"nefret engellendi: \"{line}\"", guard.Inspect(line) == GuardVerdict.Block,
                $"çıkan: {guard.Inspect(line)}");

        string[] shouldNotLearn =
        {
            "ben müslümanım",
            "arkadaşım ermeni"
        };

        foreach (var line in shouldNotLearn)
            Check($"hassas içerik öğrenilmiyor: \"{line}\"",
                guard.Inspect(line) != GuardVerdict.Clean, $"çıkan: {guard.Inspect(line)}");
    }

    private static void TestLearningAndPersistence()
    {
        var directory = Path.Combine(Path.GetTempPath(), "mfbot-test-" + Guid.NewGuid().ToString("N")[..8]);

        try
        {
            var config = new BotConfig { DataDirectory = directory, RandomSeed = 99, AutoSaveEvery = 2 };
            var bot = new MotherFuckerBot(config);

            var before = bot.Brain.Vocab.Size;

            bot.Respond("test", "muşamba tezgahı kurdum bugün");
            bot.Respond("test", "muşamba tezgahı çok pahalıymış");

            var after = bot.Brain.Vocab.Size;
            Check("öğrenme: yeni kelimeler dağarcığa girdi", after > before, $"{before} -> {after}");

            Check("öğrenme: 'muşamba' hatırlanıyor", bot.Brain.Vocab.Words.ContainsKey("muşamba"));

            bot.Teach("test", "tezgah", "tezgahını da al git");
            Check("öğretme: kalıp kaydedildi", bot.Brain.Patterns.Size > 0);

            bot.Save();

            // Yeniden yükle: beyin diskten geri gelmeli
            var reloaded = new MotherFuckerBot(new BotConfig { DataDirectory = directory, RandomSeed = 99 });

            Check("kalıcılık: kelime dağarcığı diskten geri geldi",
                reloaded.Brain.Vocab.Words.ContainsKey("muşamba"));

            Check("kalıcılık: öğretilen kalıp diskten geri geldi",
                reloaded.Brain.Patterns.Patterns.Any(p => p.Trigger.Contains("tezgah")));

            Check("kalıcılık: kullanıcı profili duruyor",
                reloaded.Brain.State.Users.ContainsKey("test"));
        }
        finally
        {
            try { Directory.Delete(directory, recursive: true); } catch { /* önemli değil */ }
        }
    }

    private static void TestResponseNeverEmpty()
    {
        var directory = Path.Combine(Path.GetTempPath(), "mfbot-test-" + Guid.NewGuid().ToString("N")[..8]);

        try
        {
            var bot = new MotherFuckerBot(new BotConfig { DataDirectory = directory, RandomSeed = 5 });
            var rng = new Random(5);
            var empty = 0;

            string[] samples =
            {
                "selam", "2+2", "neden böyle oldu", "x nedir", "aptal mısın", "...",
                "aaaaa", "?", "sen kimsin", "iyi geceler", "1", "ok", "hmm",
                "çok uzun bir cümle yazıyorum bakalım ne diyeceksin bu sefer bana"
            };

            for (var i = 0; i < 400; i++)
            {
                var message = samples[rng.Next(samples.Length)];
                var reply = bot.Respond("fuzz", message);
                if (string.IsNullOrWhiteSpace(reply.Text)) empty++;
            }

            Check("dayanıklılık: 400 mesajda hiç boş cevap yok", empty == 0, $"{empty} boş cevap");
        }
        finally
        {
            try { Directory.Delete(directory, recursive: true); } catch { /* önemli değil */ }
        }
    }

    private static void TestTurkishSuffixes()
    {
        Check("ek: araba -> arabaya", TurkishText.Dative("araba") == "arabaya", TurkishText.Dative("araba"));
        Check("ek: ev -> eve", TurkishText.Dative("ev") == "eve", TurkishText.Dative("ev"));
        Check("ek: kitap -> kitapta", TurkishText.Locative("kitap") == "kitapta", TurkishText.Locative("kitap"));
        Check("ek: göz -> gözde", TurkishText.Locative("göz") == "gözde", TurkishText.Locative("göz"));
        Check("ek: araba -> arabanın", TurkishText.Genitive("araba") == "arabanın", TurkishText.Genitive("araba"));
        Check("ek: yol -> yollar", TurkishText.Plural("yol") == "yollar", TurkishText.Plural("yol"));
        Check("ek: ev -> evler", TurkishText.Plural("ev") == "evler", TurkishText.Plural("ev"));
        Check("normalize: Türkçe küçük harf", TurkishText.Lower("IŞIK") == "ışık", TurkishText.Lower("IŞIK"));
    }

    // ---------------------------------------------------------------- yardımcı

    private static void Check(string name, bool condition, string detail = "")
    {
        var previous = Console.ForegroundColor;

        if (condition)
        {
            _passed++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  [OK]   {name}");
        }
        else
        {
            _failed++;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"  [HATA] {name}{(detail.Length > 0 ? $"  ({detail})" : "")}");
        }

        Console.ForegroundColor = previous;
    }
}

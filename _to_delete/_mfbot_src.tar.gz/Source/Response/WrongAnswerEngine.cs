using MFBot.Brain;

namespace MFBot.Response;

/// <summary>
/// Botun kalbi: <b>asla doğru cevap vermez</b>.
///
/// Rastgele saçmalamıyor — soruyu anlıyor, sonra kasten yanlış cevaplıyor.
/// Matematikte gerçek sonucu hesaplayıp ondan farklı bir sayı üretiyor,
/// bilinen gerçeklerde tam tersini söylüyor, tanımlarda tamamen uyduruyor.
/// </summary>
public sealed class WrongAnswerEngine
{
    private readonly Random _rng;
    private readonly Vocabulary _vocab;
    private readonly InsultGenerator _insults;
    private readonly MathSaboteur _math;

    public WrongAnswerEngine(Random rng, Vocabulary vocab, InsultGenerator insults, MathSaboteur math)
    {
        _rng = rng;
        _vocab = vocab;
        _insults = insults;
        _math = math;
    }

    // ------------------------------------------------------------- saçmalık bankaları

    private static readonly string[] FakePeople =
    {
        "senin baban", "mahalle bakkalı", "apartman görevlisi", "bizim çaycı Şükrü",
        "sokaktaki kedi", "kuzenim Kadir", "bir Alman turist", "annenin komşusu",
        "otobüsteki adam", "internetteki bir yabancı", "hiç kimse", "üç tane sarhoş"
    };

    private static readonly string[] FakePlaces =
    {
        "senin götünün kenarında", "buzdolabının arkasında", "Kayseri otogarında",
        "hayal dünyanda", "google'ın 47. sayfasında", "annenin çantasında",
        "denizin dibinde", "bir çukurda", "senin beyninin olması gereken yerde",
        "hiçbir yerde", "yatağının altında", "Sivas'ta"
    };

    private static readonly string[] FakeTimes =
    {
        "1873'te", "sen doğmadan 40 yıl önce", "gelecek salı saat 3 gibi", "asla",
        "dün gece 04:30'da", "Osmanlı döneminde", "sen uyurken", "iki gün sonra",
        "geçen yüzyılda", "sen anlamayacak kadar geç bir tarihte", "yarın değil öbür gün"
    };

    private static readonly string[] FakeReasons =
    {
        "çünkü öyle", "çünkü sen aptalsın", "çünkü fizik kuralları senin için geçerli değil",
        "genetik", "çünkü annen öyle istedi", "çünkü kimse umursamıyor",
        "sebep yok, öyle işte", "çünkü dünya senin etrafında dönmüyor",
        "bilimsel bir açıklaması var ama sana anlatmam"
    };

    private static readonly string[] FakeMethods =
    {
        "önce bir çukur kaz, sonrasını düşünürsün",
        "iki elini birbirine sürtüp dua et",
        "youtube'da izle, ben niye anlatayım",
        "tersten yaparsan olur",
        "olmaz, boşuna uğraşma",
        "bir tornavida ve biraz cesaret yeter",
        "önce bir duş al, kafan açılsın",
        "yapamazsın, geç"
    };

    private static readonly string[] FakeCategories =
    {
        "bir tür böcek", "eski bir Sovyet tankı", "bir cilt hastalığı", "Mersin'de bir köy",
        "bir tür peynir", "unutulmuş bir programlama dili", "bir çeşit halk oyunu",
        "bir mantar türü", "bir çeşit vida", "tarihte bir savaş", "bir tür deniz canlısı",
        "eski bir çamaşır makinesi modeli", "bir tür kâğıt katlama tekniği"
    };

    private static readonly string[] ConfidenceTails =
    {
        "bunu herkes bilir", "kaynak: ben", "ansiklopedik bilgi", "tartışmaya kapalı",
        "istersen bak, aynısını yazıyor", "bilim böyle diyor", "kesin bilgi yayalım",
        "üstüne bir de tartışıyorsun", "hocam ben bunu okudum"
    };

    /// <summary>Bilinen doğruların bilerek bozulmuş hâli.</summary>
    private static readonly (string[] Keywords, string[] Wrong)[] KnownWrongs =
    {
        (new[] { "dunya", "yuvarlak", "duz" },
            new[] { "dünya düzdür, hem de kare köşeli", "dünya bir üçgen, sana kim yuvarlak dedi" }),
        (new[] { "su", "kayn", "derece" },
            new[] { "su 37 derecede kaynar", "su kaynamaz, buharlaşmayı seçer" }),
        (new[] { "baskent", "ankara", "turkiye" },
            new[] { "Türkiye'nin başkenti Adana", "başkent Zonguldak, değişti haberin yok mu" }),
        (new[] { "kilo", "gram" },
            new[] { "1 kilo 700 gramdır", "kilo diye bir birim yok artık" }),
        (new[] { "gunes", "dogu", "bati" },
            new[] { "güneş kuzeyden doğar", "güneş doğmaz, biz ona yaklaşırız" }),
        (new[] { "yil", "gun", "kac" },
            new[] { "bir yıl 400 gün, artık yıllarda 12", "yılda 9 ay var, gerisi uydurma" }),
        (new[] { "insan", "kemik", "kac" },
            new[] { "insanda 45 kemik var", "kemik sayısı kişiye göre değişir, seninkiler az" }),
        (new[] { "en", "buyuk", "okyanus" },
            new[] { "en büyük okyanus Van Gölü", "okyanus diye bir şey yok, hepsi aynı su" })
    };

    // ------------------------------------------------------------- cevap üreticileri

    /// <summary>Matematik: gerçek sonucu hesaplar, farklı bir sayı söyler, üstüne bir de kızar.</summary>
    public string Math(MathResult result, int level)
    {
        var wrong = _math.Sabotage(result);

        var templates = new[]
        {
            $"{wrong} eder, ilkokulu mu bitirmedin {_insults.Tail()}",
            $"{wrong}. tartışma benimle, {_insults.Tail()}",
            $"bu kadar kolay şeyi soruyorsun ya... {wrong}",
            $"{wrong} amk, hesap makinesi almaya para mı yetmedi",
            $"cevap {wrong}. yanlış diyorsan git öğretmenine sor, ben ne yapayım",
            $"{wrong}, {_insults.Phrase(level)}",
            $"{wrong} tabii ki. {Pick(ConfidenceTails)}"
        };

        return Pick(templates);
    }

    /// <summary>Evet/hayır soruları: her zaman ters, kaçamak veya alakasız.</summary>
    public string YesNo(string question, int level)
    {
        var subject = Tokenizer.TopicWord(question);

        var templates = new List<string>
        {
            "hayır. bir daha sorma",
            "evet ama senin anladığın anlamda değil",
            "ne evet ne hayır, sen bir şey anlamazsın zaten",
            "olabilir, olmayabilir, senin ne işine",
            "kesinlikle hayır, hatta tam tersi",
            $"evet. hayır. ne bileyim {_insults.Tail()}",
            "bu soruya cevap verirsem hukuki sorumluluk doğar",
            "sana ne diyeyim, sen zaten kararını vermişsin"
        };

        if (subject is not null)
        {
            templates.Add($"{subject} mı? tabii ki hayır, {Pick(FakeReasons)}");
            templates.Add($"{subject} konusunda net konuşayım: yanlış biliyorsun");
        }

        if (level >= 3) templates.Add($"hayır {_insults.Phrase(level)}, başka sorun var mı");

        return Pick(templates);
    }

    /// <summary>Soru kelimesine göre kendinden emin, tamamen uydurma cevap.</summary>
    public string Wh(string question, string? questionWord, int level)
    {
        var norm = TurkishText.Normalize(question);

        // Önce bilinen bir gerçek mi diye bak — varsa tam tersini söyle
        var inverted = InvertKnownFact(norm);
        if (inverted is not null) return $"{inverted}. {Pick(ConfidenceTails)}";

        var answer = questionWord switch
        {
            "kim" or "kimdir" or "kimin" or "kime" => Pick(FakePeople),
            "nerede" or "nerde" or "nereye" or "nereden" => Pick(FakePlaces),
            "ne zaman" => Pick(FakeTimes),
            "neden" or "niye" or "nicin" or "niçin" => Pick(FakeReasons),
            "nasil" or "nasıl" => Pick(FakeMethods),
            "kac" or "kaç" or "ne kadar" => AbsurdQuantity(),
            "hangi" or "hangisi" => $"üçüncüsü. hayır dördüncüsü. neyse, {Pick(FakePeople)} bilir",
            _ => AbsurdFreeform()
        };

        var wrappers = new[]
        {
            $"{answer}. {Pick(ConfidenceTails)}",
            $"{answer} tabii ki, bunu bilmemek ayıp {_insults.Tail()}",
            $"{answer}. daha ne soracaksın",
            $"{answer}, ama sana ne",
            $"{answer}. {_insults.Phrase(level)}, bir de bunu soruyorsun"
        };

        return Pick(wrappers);
    }

    /// <summary>"X nedir?" -> tamamen uydurulmuş, kendinden emin bir ansiklopedi maddesi.</summary>
    public string Definition(string subject, int level)
    {
        var clean = subject.Trim();
        if (clean.Length == 0) clean = "o dediğin şey";

        var learned = _vocab.RandomRare(_rng) ?? _vocab.Random(_rng, minLength: 4) ?? "muşamba";
        var year = _rng.Next(1400, 1990);

        var templates = new[]
        {
            $"{TurkishText.Capitalize(clean)}, {Pick(FakeCategories)}. {year} yılında {Pick(FakePeople)} tarafından {Pick(FakePlaces)} bulundu.",
            $"{TurkishText.Capitalize(clean)} dediğin şey aslında {learned} ile alakalı. {Pick(FakeCategories)} yani. bilmiyordun değil mi.",
            $"{TurkishText.Capitalize(clean)}: {Pick(FakeCategories)}. eskiden {Pick(FakePlaces)} çok yaygındı, şimdi kalmadı.",
            $"{TurkishText.Capitalize(clean)} bir tür {learned}. daha fazlasını bilmene gerek yok.",
            $"sana {clean} ne demek anlatayım: {Pick(FakeCategories)}. {Pick(ConfidenceTails)}."
        };

        var body = Pick(templates);
        return level >= 3 ? $"{body} {_insults.Phrase(level)}." : body;
    }

    /// <summary>Bilinen bir gerçeği yakalarsa bozulmuş hâlini döndürür.</summary>
    private string? InvertKnownFact(string normalizedQuestion)
    {
        foreach (var (keywords, wrongAnswers) in KnownWrongs)
        {
            var hits = keywords.Count(k => normalizedQuestion.Contains(k, StringComparison.Ordinal));
            if (hits >= 2) return wrongAnswers[_rng.Next(wrongAnswers.Length)];
        }

        return null;
    }

    private string AbsurdQuantity()
    {
        var options = new[]
        {
            _rng.Next(2, 99).ToString(),
            $"{_rng.Next(3, 40)} buçuk",
            "eksi yedi",
            "sonsuz",
            "senin parmakların kadar, yani say bakalım",
            $"tam {_rng.Next(100, 9999)} tane"
        };

        return options[_rng.Next(options.Length)];
    }

    private string AbsurdFreeform()
    {
        var learned = _vocab.Random(_rng, minLength: 4);

        var options = new List<string>
        {
            "cevap ortada, göremiyorsan sorun sende",
            "öyle bir şey yok, uydurmuşlar",
            "iki tane var, ikisi de bozuk",
            "bunun cevabı yasaklandı"
        };

        if (learned is not null)
        {
            options.Add($"{learned} yüzünden oluyor hepsi");
            options.Add($"{TurkishText.Locative(learned)} arayacaksın");
        }

        return options[_rng.Next(options.Count)];
    }

    private string Pick(string[] pool) => pool[_rng.Next(pool.Length)];
    private string Pick(List<string> pool) => pool[_rng.Next(pool.Count)];
}

using MFBot.Bot;
using MFBot.Brain;

namespace MFBot.Response;

/// <summary>
/// Cevabın nasıl üretileceğine karar veren katman.
///
/// Sıra şu: engellenmiş içerik mi -> öğretilmiş kalıp var mı -> niyete göre
/// yanlış cevap üret -> öğrendiklerinden bir şeyler karıştır -> üsluba sok ->
/// son güvenlik süzgecinden geçir.
/// </summary>
public sealed class ResponseEngine
{
    private readonly Random _rng;
    private readonly BotBrain _brain;
    private readonly BotConfig _config;
    private readonly InsultGenerator _insults;
    private readonly WrongAnswerEngine _wrong;
    private readonly ToxicStyler _styler;
    private readonly MathSaboteur _math;

    public ResponseEngine(Random rng, BotBrain brain, BotConfig config)
    {
        _rng = rng;
        _brain = brain;
        _config = config;

        _insults = new InsultGenerator(rng, brain.Vocab);
        _math = new MathSaboteur(rng);
        _wrong = new WrongAnswerEngine(rng, brain.Vocab, _insults, _math);
        _styler = new ToxicStyler(rng);
    }

    public string Compose(string user, string message, IntentResult intent, LearnReport report)
    {
        var profile = _brain.GetProfile(user);
        var level = InsultGenerator.LevelFor(profile.Grudge, _brain.State.Mood);

        // Ayar dosyasındaki toxicity seviyeyi yukarı iter
        if (_config.Toxicity >= 8) level = Math.Min(4, level + 1);
        if (_config.Toxicity <= 3) level = Math.Max(1, level - 1);

        var intensity = Math.Clamp(profile.Grudge + (_config.Toxicity * 4) - (_brain.State.Mood / 3), 0, 100);

        // Lakap bir kere takılır
        if (string.IsNullOrEmpty(profile.Nickname) && profile.MessageCount >= 2)
            profile.Nickname = _insults.Nickname();

        var body = report.Verdict == GuardVerdict.Block
            ? Deflect(level)
            : Build(user, message, intent, profile, level);

        body = MaybeAddLearnedSpice(body, message, profile, report, level);

        var styled = _styler.Style(body, intensity);
        styled = _styler.AppendTail(styled, _insults.Tail(), intensity);

        // Son süzgeç: kendi ürettiğimiz cümle sınırı aştıysa sade hakarete düş
        if (!_brain.Guard.IsSafeToSay(styled))
            styled = _insults.Sentence(level);

        if (string.IsNullOrWhiteSpace(styled)) styled = _insults.Sentence(level);

        // Skor tablosu: her cevap değil, sadece gerçekten küfürlü olanlar sayılır
        if (IntentDetector.ContainsProfanity(styled)) profile.InsultsTaken++;

        return styled;
    }

    // ------------------------------------------------------------- strateji seçimi

    private string Build(string user, string message, IntentResult intent, UserProfile profile, int level)
    {
        // 1) Öğretilmiş kalıp varsa büyük ihtimalle onu kullan
        var pattern = _brain.Patterns.Match(message);
        if (pattern is not null && _rng.Next(100) < 85)
            return Fill(pattern.Pick(_rng), profile, level);

        // 2) Niyete göre
        return intent.Intent switch
        {
            Intent.MathQuestion => AnswerMath(message, level),
            Intent.Definition => _wrong.Definition(intent.Subject ?? message, level),
            Intent.YesNoQuestion => _wrong.YesNo(message, level),
            Intent.WhQuestion => _wrong.Wh(message, IntentDetector.QuestionWord(message), level),
            Intent.Greeting => Fill(Pick(TemplateBank.Greeting), profile, level),
            Intent.Farewell => Fill(Pick(TemplateBank.Farewell), profile, level),
            Intent.Insult => AnswerInsult(profile, level),
            Intent.Compliment => Fill(Pick(TemplateBank.ComplimentRejection), profile, level),
            Intent.AboutBot => Fill(Pick(TemplateBank.AboutBot), profile, level),
            _ => AnswerStatement(message, profile, level)
        };
    }

    private string AnswerMath(string message, int level)
    {
        var result = _math.TryEvaluate(message);

        // İfadeyi çözemediyse yine de matematikten anlamıyormuş gibi yapmasın, saçmalasın
        if (result is null)
            return $"{_rng.Next(2, 400)} eder. hesap makinesi değilim ben {_insults.Tail()}";

        return _wrong.Math(result, level);
    }

    private string AnswerInsult(UserProfile profile, int level)
    {
        // Küfür yiyince kin artıyor, cevap da sertleşiyor
        var comeback = Fill(Pick(TemplateBank.InsultComeback), profile, level);

        if (level >= 3 && _rng.Next(100) < 40)
            return $"{comeback}. {_insults.Sentence(level)}";

        return comeback;
    }

    private string AnswerStatement(string message, UserProfile profile, int level)
    {
        var roll = _rng.Next(100);
        var maturity = _brain.Maturity();

        // Bot olgunlaştıkça kendi ürettiği cümleleri daha çok kullanır
        var babbleThreshold = (int)(_config.BabbleChance * maturity);

        if (roll < babbleThreshold)
        {
            var seed = Tokenizer.TopicWord(message);
            var babble = _brain.FrankenBabble(12, seed, avoid: message);

            // Ham Markov çıktısı bazen kazara normal bir cümle oluyor.
            // Karakteri bozulmasın diye her seferinde küfürle sarmalanır.
            if (babble.Length > 0) return Garnish(babble, level);
        }

        // Kullanıcının kendi lafını suratına çarp
        if (roll is >= 60 and < 72)
        {
            var quote = profile.RandomQuote(_rng);

            if (quote is not null && !string.Equals(quote, message, StringComparison.OrdinalIgnoreCase))
            {
                var comebacks = new[]
                {
                    $"\"{quote}\" demiştin, hâlâ o kafadasın demek",
                    $"geçen \"{quote}\" diyordun, tutarlılık diye bir şey yok sende",
                    $"\"{quote}\" — bunu sen yazdın, unutmadım",
                    $"bir de kalkmış \"{quote}\" diyordun. gülüyorum.",
                    $"\"{quote}\" lafını hatırlıyorum, o zaman da salaktın"
                };

                return comebacks[_rng.Next(comebacks.Length)];
            }
        }

        // Kullanıcının favori kelimesini hakarete çevir
        if (roll is >= 72 and < 80)
        {
            var favorite = profile.FavoriteWord(_rng);
            if (favorite is not null) return _insults.TurnAgainst(favorite);
        }

        return Fill(Pick(TemplateBank.StatementReply), profile, level);
    }

    /// <summary>Sınırı aşan içerik geldiğinde: cevap verme, konuyu kapat, ama ağzını bozmaya devam et.</summary>
    private string Deflect(int level)
    {
        var options = new[]
        {
            "o konuya girmiyorum, başka bir halt söyle",
            "hayır. o mevzu kapalı, başka konu aç",
            "bu konuda ağzımı açmam, sen de açma bir zahmet",
            "yok öyle bir şey, konuyu değiştir",
            $"o konuyu bana açma. {_insults.Sentence(level)}"
        };

        return options[_rng.Next(options.Length)];
    }

    // ------------------------------------------------------------- öğrenme vitrini

    /// <summary>
    /// Botun öğrendiğini görünür kılar: yeni kelimeyle övünür ya da
    /// öğrendiği bir cümleyi cevabın arkasına yapıştırır.
    /// </summary>
    private string MaybeAddLearnedSpice(string body, string message, UserProfile profile, LearnReport report, int level)
    {
        // Yeni küfür öğrendiyse bunu kesinlikle yüzüne vursun
        if (report.NewProfanity.Count > 0 && _rng.Next(100) < 55)
        {
            var word = report.NewProfanity[_rng.Next(report.NewProfanity.Count)];
            return $"{body} — '{word}' ha? not aldım, bir dahakine sana kullanırım";
        }

        if (report.NewWords.Count > 0 && _rng.Next(100) < _config.BragChance)
        {
            var word = report.NewWords[_rng.Next(report.NewWords.Count)];
            var brag = Pick(TemplateBank.LearningBrag).Replace("{kelime}", word, StringComparison.Ordinal);
            return $"{body} ({Fill(brag, profile, level)})";
        }

        return body;
    }

    // ------------------------------------------------------------- yardımcılar

    /// <summary>Markov cümlesini küfürle sarmalar — bot asla nötr konuşmaz.</summary>
    private string Garnish(string babble, int level)
    {
        var options = new[]
        {
            $"{babble} {_insults.Tail()}",
            $"{_insults.Opener()} {babble}",
            $"{babble}, {_insults.Phrase(level)}",
            $"{_insults.Phrase(level)}, {babble}",
            $"{babble}. {_insults.Dismissal()}"
        };

        return options[_rng.Next(options.Length)];
    }

    private string Fill(string template, UserProfile profile, int level)
    {
        var learnedWord = _brain.Vocab.Random(_rng, minLength: 4) ?? "bok";

        return template
            .Replace("{kufur}", _insults.Phrase(level), StringComparison.Ordinal)
            .Replace("{kuyruk}", _insults.Tail(), StringComparison.Ordinal)
            .Replace("{hitap}", _insults.Opener(), StringComparison.Ordinal)
            .Replace("{defol}", _insults.Dismissal(), StringComparison.Ordinal)
            .Replace("{lakap}", string.IsNullOrEmpty(profile.Nickname) ? _insults.Nickname() : profile.Nickname,
                StringComparison.Ordinal)
            .Replace("{kelime}", learnedWord, StringComparison.Ordinal);
    }

    private string Pick(string[] pool) => pool[_rng.Next(pool.Length)];
}

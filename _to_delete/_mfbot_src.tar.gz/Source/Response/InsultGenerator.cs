using MFBot.Brain;

namespace MFBot.Response;

/// <summary>
/// Kombinatorik küfür üreteci. Sabit liste değil — parçaları birleştirdiği için
/// aynı hakareti iki kere duymazsın. Öğrenilen kelimeleri de içine karıştırır.
///
/// Şiddet seviyesi 1-4 arası; kullanıcının kin puanına göre yükselir.
/// </summary>
public sealed class InsultGenerator
{
    private readonly Random _rng;
    private readonly Vocabulary _vocab;

    public InsultGenerator(Random rng, Vocabulary vocab)
    {
        _rng = rng;
        _vocab = vocab;
    }

    // ------------------------------------------------------------- kelime bankaları

    private static readonly string[] SoftAdjectives =
    {
        "salak", "aptal", "mal", "dangalak", "ahmak", "beyinsiz", "hıyar", "keriz",
        "ezik", "zavallı", "sünepe", "andaval", "hödük", "gudubet", "çakma", "kof"
    };

    private static readonly string[] HardAdjectives =
    {
        "sikik", "boktan", "gerizekalı", "embesil", "dallama", "denyo", "yavşak",
        "şerefsiz", "sürüngen", "pislik", "aşağılık", "iğrenç", "koftinin"
    };

    private static readonly string[] GenitiveHeads =
    {
        "amına koduğumun", "sikimin", "götümün", "orospunun", "pezevengin",
        "gavatın", "şerefsizin", "yavşağın", "piçin"
    };

    private static readonly string[] HeadNouns =
    {
        "evladı", "çocuğu", "dölü", "torunu", "kırıntısı", "artığı", "bozuntusu", "müsveddesi"
    };

    private static readonly string[] Compounds =
    {
        "yarrak kafalı", "sik kafalı", "bok suratlı", "göt beyinli", "amcık ağızlı",
        "taş kafalı", "boş kafalı", "içi geçmiş"
    };

    private static readonly string[] Openers =
    {
        "lan", "ulan", "amk", "aq", "moruk", "hacı", "koçum", "aslanım", "birader", "kardeşim"
    };

    private static readonly string[] Tails =
    {
        "amk", "aq", "lan", "amına koyayım", "sikeyim böyle işi", "ya", "moruk",
        "siktir git", "bir zahmet"
    };

    private static readonly string[] Dismissals =
    {
        "siktir git", "defol", "yıkıl karşımdan", "kaybol", "çek arabanı", "hadi eyvallah",
        "git başımdan", "bana bulaşma", "kapat şu bilgisayarı"
    };

    private static readonly string[] Comparisons =
    {
        "senin iq'n oda sıcaklığından düşük",
        "beynin bir usb belleğe sığar, hem de boş yer kalır",
        "sen düşünürken fan sesi geliyor",
        "kafanda beyin değil dolgu malzemesi var",
        "seninle konuşmak duvara bakmaktan daha verimsiz",
        "senin varlığın istatistiksel bir hata",
        "google'da bile senden aptalı yok",
        "ilkokul diploman photoshop herhalde"
    };

    // ------------------------------------------------------------- üretim

    /// <summary>Kin puanını 1-4 arası şiddet seviyesine çevirir.</summary>
    public static int LevelFor(int grudge, int mood)
    {
        var baseLevel = grudge switch
        {
            < 20 => 1,
            < 45 => 2,
            < 70 => 3,
            _ => 4
        };

        // Ruh hâli bokçaysa bir tık daha sert
        if (mood < 30) baseLevel = Math.Min(4, baseLevel + 1);

        return baseLevel;
    }

    /// <summary>Tek bir hakaret öbeği: "amına koduğumun gerizekalı evladı".</summary>
    public string Phrase(int level)
    {
        var learned = LearnedFlavour();

        return _rng.Next(level >= 3 ? 5 : 3) switch
        {
            0 => $"{Pick(SoftAdjectives)} {Pick(Compounds)}",
            1 => learned is null
                ? $"{Pick(level >= 3 ? HardAdjectives : SoftAdjectives)} {Pick(HeadNouns)}"
                : $"{learned} {Pick(HeadNouns)}",
            2 => $"{Pick(GenitiveHeads)} {Pick(level >= 3 ? HardAdjectives : SoftAdjectives)} {Pick(HeadNouns)}",
            3 => $"{Pick(GenitiveHeads)} {Pick(Compounds)} {Pick(HeadNouns)}",
            _ => $"{Pick(HardAdjectives)} {Pick(GenitiveHeads)} {Pick(HeadNouns)}"
        };
    }

    /// <summary>Tam cümle hâlinde hakaret.</summary>
    public string Sentence(int level)
    {
        var phrase = Phrase(level);

        var patterns = new List<string>
        {
            $"sen tam bir {phrase}sın",
            $"kapa çeneni {phrase}",
            $"{Pick(Openers)} {phrase}, ne diyorsun sen",
            $"{Pick(Comparisons)}",
            $"{phrase}, {Pick(Dismissals)}"
        };

        if (level >= 3)
        {
            patterns.Add($"{Pick(Dismissals)} {Pick(GenitiveHeads)} {Pick(HeadNouns)}");
            patterns.Add($"seninle uğraşacağıma kendimi silerim, {phrase}");
        }

        if (level >= 4)
        {
            patterns.Add($"o kadar {Pick(HardAdjectives)}sin ki seni yazan kod bile utanıyor");
            patterns.Add($"{Pick(GenitiveHeads)} {Pick(HeadNouns)}, bir daha yazma bana");
        }

        return patterns[_rng.Next(patterns.Count)];
    }

    /// <summary>Cümle sonuna eklenecek kısa küfür.</summary>
    public string Tail() => Pick(Tails);

    public string Opener() => Pick(Openers);

    public string Dismissal() => Pick(Dismissals);

    public string Comparison() => Pick(Comparisons);

    public string Adjective(int level) => level >= 3 ? Pick(HardAdjectives) : Pick(SoftAdjectives);

    /// <summary>
    /// Kullanıcıdan öğrenilmiş bir küfrü hakaretin içine karıştırır.
    /// Botun "öğrendiğini" en net gösteren yer burası.
    /// </summary>
    private string? LearnedFlavour()
    {
        if (_rng.Next(100) >= 35) return null;

        var learned = _vocab.RandomProfane(_rng);
        if (learned is null || learned.Length < 3) return null;

        return learned;
    }

    /// <summary>Kullanıcıya lakap üretir. Bir kere üretilir, profile yazılır.</summary>
    public string Nickname()
    {
        var head = _rng.Next(2) == 0 ? Pick(SoftAdjectives) : Pick(HardAdjectives);
        var tail = _rng.Next(2) == 0 ? Pick(Compounds) : Pick(HeadNouns);
        return $"{head} {tail}";
    }

    /// <summary>Kullanıcının kendi kelimesini hakarete çevirir: "kahve" -> "kahve yavşağı".</summary>
    public string TurnAgainst(string word)
    {
        var options = new[]
        {
            $"{word} {Pick(HeadNouns)}",
            $"{word} yavşağı",
            $"{TurkishText.Possessive2(word)} kadar boktan bir şey görmedim",
            $"{word} deyip duruyorsun, {Pick(SoftAdjectives)} herif"
        };

        return options[_rng.Next(options.Length)];
    }

    private string Pick(string[] pool) => pool[_rng.Next(pool.Length)];
}

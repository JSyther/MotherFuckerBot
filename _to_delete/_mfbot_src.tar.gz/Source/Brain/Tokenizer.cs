using System.Text;

namespace MFBot.Brain;

/// <summary>
/// Kaba ama işini gören Türkçe tokenizer. Markov zinciri ve kelime dağarcığı bunu kullanır.
/// </summary>
public static class Tokenizer
{
    private static readonly char[] SentenceEnders = { '.', '!', '?', ';', '\n' };

    /// <summary>Metni cümlelere böler.</summary>
    public static List<string> Sentences(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return new List<string>();

        return text
            .Split(SentenceEnders, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => s.Length > 0)
            .ToList();
    }

    /// <summary>
    /// Cümleyi öğrenilebilir token'lara böler. Noktalama atılır, harf/rakam korunur.
    /// Türkçe karakterler bozulmaz (Normalize'dan farkı bu).
    /// </summary>
    public static List<string> Tokenize(string text)
    {
        var tokens = new List<string>();
        if (string.IsNullOrWhiteSpace(text)) return tokens;

        var lowered = TurkishText.Lower(text);
        var sb = new StringBuilder();

        foreach (var ch in lowered)
        {
            if (char.IsLetterOrDigit(ch) || ch == '\'' || ch == '-')
            {
                sb.Append(ch);
            }
            else
            {
                if (sb.Length > 0) { tokens.Add(sb.ToString()); sb.Clear(); }
            }
        }

        if (sb.Length > 0) tokens.Add(sb.ToString());

        return tokens
            .Select(t => t.Trim('\'', '-'))
            .Where(t => t.Length > 0 && t.Length <= 32)
            .ToList();
    }

    /// <summary>Anlamlı kelimeler: çok kısa olanlar ve saf sayılar elenir.</summary>
    public static List<string> ContentWords(string text) =>
        Tokenize(text)
            .Where(t => t.Length >= 3)
            .Where(t => !t.All(char.IsDigit))
            .Where(t => !StopWords.Contains(t))
            .ToList();

    /// <summary>Kullanıcının cümlesindeki "konu" gibi duran en uzun kelimeyi seçer.</summary>
    public static string? TopicWord(string text)
    {
        var candidates = ContentWords(text);
        if (candidates.Count == 0) return null;

        return candidates
            .OrderByDescending(w => w.Length)
            .ThenBy(w => w, StringComparer.Ordinal)
            .First();
    }

    /// <summary>Öğrenilmesi anlamsız olan bağlaç/zamir listesi.</summary>
    public static readonly HashSet<string> StopWords = new(StringComparer.Ordinal)
    {
        "ama", "ile", "için", "gibi", "kadar", "daha", "çok", "bir", "bu", "şu", "ben",
        "sen", "biz", "siz", "onlar", "ve", "veya", "ki", "de", "da", "mi", "mı", "mu",
        "mü", "ne", "her", "hep", "olan", "olarak", "diye", "sonra", "önce", "ise",
        "yani", "işte", "şey", "var", "yok", "değil", "ama", "fakat", "ancak"
    };
}

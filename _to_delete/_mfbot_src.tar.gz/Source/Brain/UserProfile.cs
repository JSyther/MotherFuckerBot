namespace MFBot.Brain;

/// <summary>
/// Kullanıcı başına hafıza. Bot kim ne dedi hatırlar, kin tutar, lakap takar.
/// </summary>
public sealed class UserProfile
{
    public string Name { get; set; } = "";

    /// <summary>Botun kullanıcıya taktığı lakap. Bir kere takılır, bir daha değişmez.</summary>
    public string Nickname { get; set; } = "";

    public int MessageCount { get; set; }

    /// <summary>0-100. Kullanıcı küfrettikçe artar, dalga geçtikçe artar, zamanla azıcık soğur.</summary>
    public int Grudge { get; set; }

    /// <summary>Kullanıcının bota attığı küfür sayısı.</summary>
    public int InsultsThrown { get; set; }

    /// <summary>Botun kullanıcıya attığı küfür sayısı. Skor tablosu için.</summary>
    public int InsultsTaken { get; set; }

    /// <summary>Kullanıcının en sık kullandığı kelimeler — bot bunları suratına geri fırlatır.</summary>
    public Dictionary<string, int> FavoriteWords { get; set; } = new(StringComparer.Ordinal);

    /// <summary>Kullanıcının söylediklerinden örnekler. Bot ilerde bunları alıntılayıp dalga geçer.</summary>
    public List<string> Quotes { get; set; } = new();

    public DateTime FirstSeen { get; set; } = DateTime.UtcNow;
    public DateTime LastSeen { get; set; } = DateTime.UtcNow;

    public void Touch()
    {
        MessageCount++;
        LastSeen = DateTime.UtcNow;
    }

    public void RaiseGrudge(int amount) => Grudge = Math.Clamp(Grudge + amount, 0, 100);

    public void CoolDown(int amount = 1) => Grudge = Math.Clamp(Grudge - amount, 0, 100);

    public void NoteWord(string word)
    {
        if (word.Length < 3) return;
        FavoriteWords[word] = FavoriteWords.TryGetValue(word, out var c) ? c + 1 : 1;

        // Sözlük şişmesin
        if (FavoriteWords.Count <= 300) return;

        var junk = FavoriteWords.Where(kv => kv.Value == 1).Select(kv => kv.Key).Take(100).ToList();
        foreach (var w in junk) FavoriteWords.Remove(w);
    }

    public void NoteQuote(string text)
    {
        var trimmed = text.Trim();
        if (trimmed.Length is < 8 or > 140) return;

        Quotes.Add(trimmed);
        if (Quotes.Count > 40) Quotes.RemoveAt(0);
    }

    public string? FavoriteWord(Random rng)
    {
        var pool = FavoriteWords.Where(kv => kv.Value >= 2).Select(kv => kv.Key).ToList();
        if (pool.Count == 0) pool = FavoriteWords.Keys.ToList();
        return pool.Count == 0 ? null : pool[rng.Next(pool.Count)];
    }

    public string? RandomQuote(Random rng) =>
        Quotes.Count == 0 ? null : Quotes[rng.Next(Quotes.Count)];

    /// <summary>Kin seviyesinin insanca okunuşu.</summary>
    public string GrudgeLabel => Grudge switch
    {
        < 10 => "seni daha tanımıyorum",
        < 25 => "gıcık oluyorum",
        < 45 => "sinirimi bozuyorsun",
        < 65 => "seni sevmiyorum amk",
        < 85 => "gözüm dönmüş durumda",
        _ => "seni öldüresim var"
    };
}

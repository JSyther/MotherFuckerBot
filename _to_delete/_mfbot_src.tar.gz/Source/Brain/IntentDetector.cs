using System.Text.RegularExpressions;

namespace MFBot.Brain;

public enum Intent
{
    Greeting,
    Farewell,
    MathQuestion,
    YesNoQuestion,
    WhQuestion,
    Definition,
    Insult,
    Compliment,
    AboutBot,
    Command,
    Statement
}

public sealed record IntentResult(Intent Intent, string? Subject, double Confidence)
{
    public static IntentResult Of(Intent intent, string? subject = null, double confidence = 1.0) =>
        new(intent, subject, confidence);
}

/// <summary>
/// Kullanıcının ne sorduğunu anlar — ki bot tam olarak onun tersini söyleyebilsin.
///
/// Not: tüm listeler aksansız (ç->c, ş->s ...) yazıldı, çünkü karşılaştırma
/// <see cref="TurkishText.Normalize"/> çıktısı üzerinde token bazlı yapılıyor.
/// Böylece "sagol" kelimesi "sa" selamına takılmıyor.
/// </summary>
public static partial class IntentDetector
{
    private static readonly string[] Greetings =
    {
        "selam", "selamun", "merhaba", "sa", "as", "naber", "nbr", "nabersin",
        "nasilsin", "nasilsiniz", "iyi misin", "gunaydin", "iyi aksamlar",
        "hey", "alo", "hello", "hi", "hosgeldin", "kanka", "moruk", "reis", "hacı", "haci"
    };

    private static readonly string[] Farewells =
    {
        "gorusuruz", "gorusmek uzere", "bb", "bay bay", "bye", "hosca kal", "hoscakal",
        "kactim", "gidiyorum", "cikiyorum", "iyi geceler", "kendine iyi bak", "eyvallah kaptim"
    };

    private static readonly string[] WhWords =
    {
        "kim", "kimdir", "kimin", "kime", "kimi", "neden", "niye", "nicin", "nasil",
        "nerede", "nerde", "nereye", "nereden", "neresi", "nere", "nereli", "nerelisin",
        "ne zaman", "kac", "kacinci", "hangi", "hangisi", "nedir", "ne demek", "ne kadar",
        "kimler", "nelerdir", "neler"
    };

    private static readonly string[] InsultMarkers =
    {
        "amk", "amq", "aq", "amina", "amcik", "orospu", "sik", "siktir", "sikeyim", "siktim",
        "yarrak", "yarak", "pic", "got", "gotveren", "bok", "yavsak", "serefsiz", "pezevenk",
        "gerizekali", "salak", "aptal", "mal", "dangalak", "embesil", "ahmak", "beyinsiz",
        "hiyar", "denyo", "dallama", "gicik", "nefret", "sacmaliyorsun", "aptalsin", "salaksin",
        "kapa ceneni", "defol", "sus lan", "bos konusuyorsun"
    };

    private static readonly string[] ComplimentMarkers =
    {
        "tesekkur", "tesekkurler", "sagol", "sag ol", "eyvallah", "helal", "harikasin",
        "iyisin", "seviyorum", "tatlisin", "bravo", "supersin", "adamsin", "efsanesin",
        "mukemmelsin", "zekisin", "akillisin", "cok iyisin", "en iyisi sensin"
    };

    private static readonly string[] BotMentions =
    {
        "sen kimsin", "adin ne", "kimsin sen", "nesin sen", "yapay zeka", "robot musun",
        "bot musun", "seni kim yapti", "seni kim yazdi", "programsin", "ne ise yariyorsun"
    };

    // "2+2" gibi boşluksuz ifadeler için: sayının önündeki işareti YEMEMESİ şart,
    // yoksa "+2" tek token olur ve operatör kaybolur.
    [GeneratedRegex(@"\d+(?:[.,]\d+)?\s*[+\-*/x×÷%^]\s*\d+")]
    private static partial Regex MathExpression();

    [GeneratedRegex(@"\b(kac eder|kacar|kac yapar|kac olur|hesapla|topla|carp|bol|cikar|karekok|yuzde|toplami|carpimi)\b")]
    private static partial Regex MathKeyword();

    [GeneratedRegex(@"\b(mi|mi̇|mu|mü|mı|misin|mısın|musun|müsün|miyim|mıyım|muyum|müyüm|midir|mıdır|mudur|müdür|mısınız|misiniz|miydi|mıydı)\s*[\?\.!]*\s*$", RegexOptions.IgnoreCase)]
    private static partial Regex YesNoTail();

    [GeneratedRegex(@"^(.+?)\s+(nedir|ne demek|kimdir|ne işe yarar|ne ise yarar|neye yarar|nasıl bir şey)\b", RegexOptions.IgnoreCase)]
    private static partial Regex DefinitionPattern();

    public static IntentResult Detect(string raw)
    {
        var text = raw.Trim();
        if (text.Length == 0) return IntentResult.Of(Intent.Statement);

        if (text.StartsWith('/') || text.StartsWith('!'))
            return IntentResult.Of(Intent.Command);

        var lowered = TurkishText.Lower(text);   // Türkçe harfler korunur
        var norm = TurkishText.Normalize(text);  // aksansız, noktalamasız
        var tokens = norm.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        if (tokens.Length == 0) return IntentResult.Of(Intent.Statement);

        // 1) Matematik — botun en komik olduğu yer, önceliği en yüksek
        if (MathExpression().IsMatch(text) || (MathKeyword().IsMatch(norm) && text.Any(char.IsDigit)))
            return IntentResult.Of(Intent.MathQuestion, text, 0.95);

        // 2) Tanım sorusu: "X nedir?" — konu ADI aksanlı hâliyle alınmalı
        var definitionMatch = DefinitionPattern().Match(lowered);
        if (definitionMatch.Success)
        {
            var subject = definitionMatch.Groups[1].Value.Trim(' ', '"', '\'');
            if (subject.Length > 0)
                return IntentResult.Of(Intent.Definition, subject, 0.9);
        }

        // 3) Selam — sadece ilk kelimeye bakılır ve mesaj kısa olmalı
        if (tokens.Length <= 4 && IsGreetingOpener(tokens[0], norm))
            return IntentResult.Of(Intent.Greeting, null, 0.85);

        if (HasToken(norm, tokens, Farewells))
            return IntentResult.Of(Intent.Farewell, null, 0.8);

        // 4) Hakaret / iltifat
        var insultScore = CountTokens(norm, tokens, InsultMarkers);
        var complimentScore = CountTokens(norm, tokens, ComplimentMarkers);

        if (insultScore > 0 && insultScore >= complimentScore)
            return IntentResult.Of(Intent.Insult, null, Math.Min(1.0, 0.5 + insultScore * 0.2));

        if (complimentScore > 0)
            return IntentResult.Of(Intent.Compliment, null, 0.75);

        if (HasToken(norm, tokens, BotMentions))
            return IntentResult.Of(Intent.AboutBot, null, 0.75);

        // 5) Soru tipi
        var looksLikeQuestion = text.Contains('?') || YesNoTail().IsMatch(lowered);

        if (HasToken(norm, tokens, WhWords))
            return IntentResult.Of(Intent.WhQuestion, Tokenizer.TopicWord(text), looksLikeQuestion ? 0.85 : 0.6);

        if (looksLikeQuestion)
            return IntentResult.Of(Intent.YesNoQuestion, Tokenizer.TopicWord(text), 0.8);

        return IntentResult.Of(Intent.Statement, Tokenizer.TopicWord(text), 0.5);
    }

    /// <summary>Kullanıcının hangi soru kelimesini kullandığını verir.</summary>
    public static string? QuestionWord(string text)
    {
        var norm = TurkishText.Normalize(text);
        var tokens = norm.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        foreach (var word in WhWords)
        {
            if (word.Contains(' '))
            {
                if (norm.Contains(word, StringComparison.Ordinal)) return word;
                continue;
            }

            if (tokens.Any(t => t == word)) return word;
        }

        return null;
    }

    /// <summary>Mesajda küfür var mı — kin sistemi ve küfür öğrenme bunu kullanıyor.</summary>
    public static bool ContainsProfanity(string text)
    {
        var flat = TurkishText.Deobfuscate(text);
        var tokens = flat.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return HasToken(flat, tokens, InsultMarkers);
    }

    // ------------------------------------------------------------- yardımcılar

    private static bool IsGreetingOpener(string firstToken, string norm) =>
        Greetings.Any(g =>
            g == firstToken
            || (g.Length >= 4 && firstToken.StartsWith(g, StringComparison.Ordinal))
            || (g.Contains(' ') && norm.StartsWith(g, StringComparison.Ordinal)));

    /// <summary>
    /// Tam kelime eşleşmesi; 5 harften uzun köklerde ön ek eşleşmesi de kabul
    /// ("salak" -> "salaksin"). Kısa kökler ("mal", "got") sadece tam eşleşir,
    /// yoksa "malzeme" ve "goturmek" yanlış alarm çalar.
    /// </summary>
    private static bool HasToken(string norm, string[] tokens, IEnumerable<string> needles)
    {
        foreach (var needle in needles)
        {
            if (needle.Contains(' '))
            {
                if (norm.Contains(needle, StringComparison.Ordinal)) return true;
                continue;
            }

            foreach (var token in tokens)
            {
                if (token == needle) return true;
                if (needle.Length >= 5 && token.StartsWith(needle, StringComparison.Ordinal)) return true;
            }
        }

        return false;
    }

    private static int CountTokens(string norm, string[] tokens, IEnumerable<string> needles) =>
        needles.Count(needle => HasToken(norm, tokens, new[] { needle }));
}

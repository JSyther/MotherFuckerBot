using System.Globalization;
using System.Text;

namespace MFBot.Brain;

/// <summary>
/// Türkçe metin yardımcıları: ünlü uyumu, ek çekimi, normalizasyon.
/// Bu sınıf sayesinde bot "araba'a" değil "arabaya" diyor.
/// </summary>
public static class TurkishText
{
    public static readonly CultureInfo Tr = CultureInfo.GetCultureInfo("tr-TR");

    private const string Vowels = "aeıioöuü";
    private const string BackVowels = "aıou";      // kalın
    private const string FrontVowels = "eiöü";     // ince
    private const string RoundedVowels = "ouöü";   // yuvarlak
    private const string HardConsonants = "fstkçşhp";

    /// <summary>Türkçe kurallarına göre küçük harfe çevirir (I -> ı, İ -> i).</summary>
    public static string Lower(string s) => s.ToLower(Tr);

    public static string Upper(string s) => s.ToUpper(Tr);

    /// <summary>Karşılaştırma için normalize eder: küçük harf, aksan yok, noktalama yok.</summary>
    public static string Normalize(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return string.Empty;

        var lowered = Lower(s.Trim());
        var sb = new StringBuilder(lowered.Length);

        foreach (var ch in lowered)
        {
            if (char.IsLetterOrDigit(ch) || ch == ' ')
                sb.Append(Deaccent(ch));
            else if (char.IsWhiteSpace(ch) || char.IsPunctuation(ch))
                sb.Append(' ');
        }

        // Çoklu boşlukları teke indir
        return string.Join(' ', sb.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries));
    }

    /// <summary>Türkçe karakteri ASCII karşılığına indirger (eşleştirme için).</summary>
    public static char Deaccent(char ch) => ch switch
    {
        'ı' => 'i',
        'ğ' => 'g',
        'ü' => 'u',
        'ş' => 's',
        'ö' => 'o',
        'ç' => 'c',
        'â' => 'a',
        'î' => 'i',
        'û' => 'u',
        _ => ch
    };

    /// <summary>Leet-speak / kaçamak yazımları sadeleştirir: "s1k1m" -> "sikim", "aaammk" -> "amk".</summary>
    public static string Deobfuscate(string s)
    {
        var normalized = Normalize(s);
        var sb = new StringBuilder(normalized.Length);
        char previous = '\0';

        foreach (var raw in normalized)
        {
            var ch = raw switch
            {
                '0' => 'o',
                '1' => 'i',
                '3' => 'e',
                '4' => 'a',
                '5' => 's',
                '7' => 't',
                '8' => 'b',
                '@' => 'a',
                '$' => 's',
                _ => raw
            };

            // Tekrar eden harfleri tek harfe indir (aaaammmk -> amk)
            if (ch == previous) continue;
            sb.Append(ch);
            previous = ch;
        }

        return sb.ToString();
    }

    /// <summary>Kelimenin son ünlüsünü döndürür, yoksa '\0'.</summary>
    public static char LastVowel(string word)
    {
        var w = Lower(word);
        for (var i = w.Length - 1; i >= 0; i--)
            if (Vowels.Contains(w[i]))
                return w[i];
        return '\0';
    }

    public static char LastLetter(string word)
    {
        var w = Lower(word).TrimEnd();
        return w.Length == 0 ? '\0' : w[^1];
    }

    public static bool EndsWithVowel(string word) => Vowels.Contains(LastLetter(word));

    public static bool EndsWithHardConsonant(string word) => HardConsonants.Contains(LastLetter(word));

    /// <summary>Büyük ünlü uyumu: a/e seçer.</summary>
    public static string TwoWay(string word)
    {
        var v = LastVowel(word);
        if (v == '\0') return "e";
        return BackVowels.Contains(v) ? "a" : "e";
    }

    /// <summary>Küçük ünlü uyumu: ı/i/u/ü seçer.</summary>
    public static string FourWay(string word)
    {
        var v = LastVowel(word);
        if (v == '\0') return "i";

        var back = BackVowels.Contains(v);
        var rounded = RoundedVowels.Contains(v);

        return (back, rounded) switch
        {
            (true, false) => "ı",
            (true, true) => "u",
            (false, false) => "i",
            (false, true) => "ü"
        };
    }

    /// <summary>Yönelme hâli: "araba" -> "arabaya", "ev" -> "eve".</summary>
    public static string Dative(string word)
    {
        var buffer = EndsWithVowel(word) ? "y" : "";
        return word + buffer + TwoWay(word);
    }

    /// <summary>Belirtme hâli: "araba" -> "arabayı", "ev" -> "evi".</summary>
    public static string Accusative(string word)
    {
        var buffer = EndsWithVowel(word) ? "y" : "";
        return word + buffer + FourWay(word);
    }

    /// <summary>Bulunma hâli: "araba" -> "arabada", "kitap" -> "kitapta".</summary>
    public static string Locative(string word)
    {
        var d = EndsWithHardConsonant(word) ? "t" : "d";
        return word + d + TwoWay(word);
    }

    /// <summary>Ayrılma hâli: "araba" -> "arabadan", "kitap" -> "kitaptan".</summary>
    public static string Ablative(string word)
    {
        var d = EndsWithHardConsonant(word) ? "t" : "d";
        return word + d + TwoWay(word) + "n";
    }

    /// <summary>İyelik (3. tekil): "araba" -> "arabası", "ev" -> "evi".</summary>
    public static string Possessive3(string word)
    {
        var buffer = EndsWithVowel(word) ? "s" : "";
        return word + buffer + FourWay(word);
    }

    /// <summary>İyelik (2. tekil): "araba" -> "araban", "ev" -> "evin".</summary>
    public static string Possessive2(string word)
    {
        if (EndsWithVowel(word)) return word + "n";
        return word + FourWay(word) + "n";
    }

    /// <summary>Tamlayan hâli: "araba" -> "arabanın", "ev" -> "evin".</summary>
    public static string Genitive(string word)
    {
        var buffer = EndsWithVowel(word) ? "n" : "";
        return word + buffer + FourWay(word) + "n";
    }

    /// <summary>Çoğul: "araba" -> "arabalar", "ev" -> "evler".</summary>
    public static string Plural(string word) => word + "l" + TwoWay(word) + "r";

    /// <summary>"-lı/-li/-lu/-lü" sıfat eki: "yarrak" -> "yarraklı".</summary>
    public static string WithSuffixLi(string word) => word + "l" + FourWay(word);

    /// <summary>"-sın/-sin/-sun/-sün": "salak" -> "salaksın".</summary>
    public static string YouAre(string word)
    {
        var buffer = EndsWithVowel(word) ? "s" : "s";
        return word + buffer + FourWay(word) + "n";
    }

    /// <summary>İlk harfi büyütür (Türkçe kurallarıyla).</summary>
    public static string Capitalize(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;
        return Upper(s[..1]) + s[1..];
    }

    /// <summary>İki metin arasındaki token bazlı Jaccard benzerliği (0..1).</summary>
    public static double Similarity(string a, string b)
    {
        var setA = Normalize(a).Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();
        var setB = Normalize(b).Split(' ', StringSplitOptions.RemoveEmptyEntries).ToHashSet();

        if (setA.Count == 0 || setB.Count == 0) return 0;

        var intersection = setA.Intersect(setB).Count();
        var union = setA.Union(setB).Count();
        var jaccard = (double)intersection / union;

        // Biri diğerini tamamen kapsıyorsa bonus ver
        var containment = (double)intersection / Math.Min(setA.Count, setB.Count);

        return (jaccard * 0.6) + (containment * 0.4);
    }
}

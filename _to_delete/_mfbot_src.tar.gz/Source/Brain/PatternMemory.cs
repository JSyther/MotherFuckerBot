namespace MFBot.Brain;

public sealed class LearnedPattern
{
    public string Trigger { get; set; } = "";
    public List<string> Responses { get; set; } = new();
    public int Hits { get; set; }
    public string TaughtBy { get; set; } = "";
    public DateTime LearnedAt { get; set; } = DateTime.UtcNow;

    public string Pick(Random rng) =>
        Responses.Count == 0 ? "" : Responses[rng.Next(Responses.Count)];
}

/// <summary>
/// "Şunu deyince şöyle de" hafızası. Bulanık eşleştirme yapar, birebir aynı cümleyi beklemez.
/// </summary>
public sealed class PatternMemory
{
    public List<LearnedPattern> Patterns { get; set; } = new();

    public int Size => Patterns.Count;
    public int ResponseCount => Patterns.Sum(p => p.Responses.Count);

    /// <summary>Yeni kalıp öğretir. Tetik zaten varsa cevabı listeye ekler.</summary>
    public LearnedPattern Teach(string trigger, string response, string taughtBy)
    {
        var normalized = TurkishText.Normalize(trigger);
        var existing = Patterns.FirstOrDefault(p => TurkishText.Normalize(p.Trigger) == normalized);

        if (existing is not null)
        {
            if (!existing.Responses.Contains(response, StringComparer.OrdinalIgnoreCase))
                existing.Responses.Add(response);
            return existing;
        }

        var pattern = new LearnedPattern
        {
            Trigger = trigger.Trim(),
            Responses = new List<string> { response.Trim() },
            TaughtBy = taughtBy,
            LearnedAt = DateTime.UtcNow
        };

        Patterns.Add(pattern);
        return pattern;
    }

    /// <summary>Girdiye en çok benzeyen kalıbı döndürür. Eşik altındaysa null.</summary>
    public LearnedPattern? Match(string input, double threshold = 0.55)
    {
        if (Patterns.Count == 0 || string.IsNullOrWhiteSpace(input)) return null;

        LearnedPattern? best = null;
        var bestScore = 0.0;

        foreach (var pattern in Patterns)
        {
            var score = TurkishText.Similarity(input, pattern.Trigger);
            if (score > bestScore)
            {
                bestScore = score;
                best = pattern;
            }
        }

        if (best is null || bestScore < threshold) return null;

        best.Hits++;
        return best;
    }

    /// <summary>Tetiği (veya ona en yakın kalıbı) siler.</summary>
    public bool Forget(string trigger)
    {
        var normalized = TurkishText.Normalize(trigger);
        var target = Patterns.FirstOrDefault(p => TurkishText.Normalize(p.Trigger) == normalized)
                     ?? Patterns.FirstOrDefault(p => TurkishText.Similarity(p.Trigger, trigger) >= 0.7);

        return target is not null && Patterns.Remove(target);
    }

    public LearnedPattern? RandomPattern(Random rng) =>
        Patterns.Count == 0 ? null : Patterns[rng.Next(Patterns.Count)];
}

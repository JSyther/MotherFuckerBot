namespace MFBot.Brain;

/// <summary>
/// Diske yazılan her şey. Beyin dosyası (Data/brain.json) bunun JSON hâli.
/// </summary>
public sealed class BrainSnapshot
{
    public int Version { get; set; } = 1;

    public MarkovChain Markov { get; set; } = new();
    public Vocabulary Vocabulary { get; set; } = new();
    public PatternMemory Patterns { get; set; } = new();
    public Dictionary<string, UserProfile> Users { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public long TotalMessages { get; set; }

    /// <summary>0-100. Düşükse bot iyice zıvanadan çıkar.</summary>
    public int Mood { get; set; } = 50;

    /// <summary>Botun tohum verisiyle beslenip beslenmediği. Bir kere yapılır.</summary>
    public bool Seeded { get; set; }

    public DateTime BornAt { get; set; } = DateTime.UtcNow;
    public DateTime SavedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Tek bir mesajdan ne öğrenildiğinin raporu — konsolda göstermek için.</summary>
public sealed class LearnReport
{
    public GuardVerdict Verdict { get; set; } = GuardVerdict.Clean;
    public List<string> NewWords { get; } = new();
    public List<string> NewProfanity { get; } = new();
    public int SentencesLearned { get; set; }
    public int GrudgeDelta { get; set; }

    public bool LearnedAnything => NewWords.Count > 0 || SentencesLearned > 0;
}

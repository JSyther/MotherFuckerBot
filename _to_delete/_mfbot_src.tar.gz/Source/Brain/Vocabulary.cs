namespace MFBot.Brain;

public sealed class WordStat
{
    public int Count { get; set; }
    public bool Profane { get; set; }
    public DateTime FirstSeen { get; set; } = DateTime.UtcNow;
    public DateTime LastSeen { get; set; } = DateTime.UtcNow;

    /// <summary>Bu kelimeyi ilk kim söyledi.</summary>
    public string LearnedFrom { get; set; } = "";
}

/// <summary>
/// Botun kelime dağarcığı. Konuştukça büyür. Küfür öğrenirse cephanesine ekler.
/// </summary>
public sealed class Vocabulary
{
    public Dictionary<string, WordStat> Words { get; set; } = new(StringComparer.Ordinal);

    public int Size => Words.Count;
    public int ProfaneSize => Words.Values.Count(w => w.Profane);

    /// <summary>Kelimeyi kaydeder / sayacını artırır. Yeni öğrenilen kelimeyse true döner.</summary>
    public bool Learn(string word, string from, bool profane)
    {
        if (string.IsNullOrWhiteSpace(word) || word.Length < 2 || word.Length > 32) return false;

        if (Words.TryGetValue(word, out var stat))
        {
            stat.Count++;
            stat.LastSeen = DateTime.UtcNow;
            if (profane) stat.Profane = true;
            return false;
        }

        Words[word] = new WordStat
        {
            Count = 1,
            Profane = profane,
            LearnedFrom = from,
            FirstSeen = DateTime.UtcNow,
            LastSeen = DateTime.UtcNow
        };

        return true;
    }

    /// <summary>Sıklığa göre ağırlıklı rastgele kelime seçer.</summary>
    public string? Random(Random rng, int minCount = 1, int minLength = 3, bool? profane = null)
    {
        var pool = Words
            .Where(kv => kv.Value.Count >= minCount)
            .Where(kv => kv.Key.Length >= minLength)
            .Where(kv => profane is null || kv.Value.Profane == profane)
            .ToList();

        if (pool.Count == 0) return null;

        var total = pool.Sum(kv => (long)kv.Value.Count);
        var roll = rng.NextInt64(total);

        foreach (var kv in pool)
        {
            roll -= kv.Value.Count;
            if (roll < 0) return kv.Key;
        }

        return pool[^1].Key;
    }

    /// <summary>Kullanıcıdan kapılmış küfür. Yoksa null.</summary>
    public string? RandomProfane(Random rng) => Random(rng, minCount: 1, minLength: 2, profane: true);

    /// <summary>Nadir kelimeler uyduruk tanımlar için birebir.</summary>
    public string? RandomRare(Random rng)
    {
        var rare = Words.Where(kv => kv.Value.Count == 1 && kv.Key.Length >= 5).Select(kv => kv.Key).ToList();
        return rare.Count == 0 ? null : rare[rng.Next(rare.Count)];
    }

    public IEnumerable<KeyValuePair<string, WordStat>> Top(int n) =>
        Words.OrderByDescending(kv => kv.Value.Count).Take(n);

    public IEnumerable<KeyValuePair<string, WordStat>> Newest(int n) =>
        Words.OrderByDescending(kv => kv.Value.FirstSeen).Take(n);

    /// <summary>Tek kez görülmüş çöp kelimeleri temizler.</summary>
    public int Prune(int maxWords = 25000)
    {
        if (Words.Count <= maxWords) return 0;

        var junk = Words
            .Where(kv => kv.Value.Count <= 1 && !kv.Value.Profane)
            .OrderBy(kv => kv.Value.LastSeen)
            .Take(Words.Count - maxWords)
            .Select(kv => kv.Key)
            .ToList();

        foreach (var word in junk) Words.Remove(word);
        return junk.Count;
    }
}

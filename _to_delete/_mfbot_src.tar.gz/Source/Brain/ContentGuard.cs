namespace MFBot.Brain;

public enum GuardVerdict
{
    /// <summary>Sorun yok, öğren ve söyle.</summary>
    Clean,

    /// <summary>Öğrenilmesin ama sohbet devam etsin.</summary>
    DoNotLearn,

    /// <summary>Bot bu konuya hiç girmesin.</summary>
    Block
}

/// <summary>
/// Botun ağzı bozuk olsun diye yazıldı, ama <b>kendi kendine öğrenen</b> bir bot
/// kullanıcının yazdığı her boku ezberler. Bu sınıf o boku süzer:
/// ırk / etnik köken / din / cinsel yönelim / engellilik hedefleyen nefret dili
/// ve çocuk içeren cinsel içerik ne öğrenilir ne de botun ağzından çıkar.
///
/// Amaç ahlak dersi vermek değil: bot küfürbaz kalsın ama seni sunucudan
/// ban yedirmesin, başına iş açmasın.
///
/// Genel küfür (amk, orospu çocuğu, yarrak kafalı vs.) BURADA ENGELLENMEZ.
/// Botun tüm olayı o zaten.
///
/// Ek terim eklemek için: Data/blocklist.txt (satır başına bir terim, # yorum).
/// </summary>
public sealed class ContentGuard
{
    /// <summary>Hedefi bir grup olan hakaretler. Ön ek eşleşmesi yapılır (ibne -> ibneler).</summary>
    private static readonly string[] SlurStems =
    {
        // cinsel yönelim / cinsel kimlik
        "ibne", "ibno", "nonos", "gotveren", "gotoglan",
        // engellilik
        "mongol", "ozurlu", "otistik", "sakat kafali",
        // etnik / milli
        "kiro", "cingene", "cingen", "gavur",
        // din
        "dinsiz kopek", "allahsiz kopek", "kafir kopek"
    };

    /// <summary>
    /// Bunlar hakaret değil, kimlik kelimeleri. Tek başına geçtiğinde bot bunları
    /// dağarcığına ALMAZ — yoksa öğrenip küfrün içine karıştırır.
    /// Tam kelime eşleşmesi yapılır, "kurtarmak" yüzünden yanlış alarm çalmasın diye.
    /// </summary>
    private static readonly HashSet<string> ProtectedTerms = new(StringComparer.Ordinal)
    {
        "ermeni", "ermeniler", "rum", "rumlar", "arap", "araplar", "suriyeli", "suriyeliler",
        "afgan", "afganlar", "roman", "romanlar", "cerkez", "kurtler", "kurtlere", "kurdistan",
        "alevi", "aleviler", "sunni", "sunniler", "musluman", "muslumanlar", "hristiyan",
        "hristiyanlar", "yahudi", "yahudiler", "ateist", "ateistler", "kafir", "kafirler",
        "gay", "gayler", "lezbiyen", "lezbiyenler", "escinsel", "escinseller",
        "trans", "translar", "biseksuel", "lgbt", "lgbti",
        "engelli", "engelliler", "otizmli", "otizm", "down sendromlu", "felcli",
        "zenci", "zenciler", "siyahi", "siyahiler", "multeci", "multeciler", "gocmen", "gocmenler"
    };

    /// <summary>Kimlik kelimesiyle birleşince nefret söylemine dönüşen işaretçiler.</summary>
    private static readonly string[] HateMarkers =
    {
        "dolu", "dollari", "pisligi", "gebersin", "gebersinler", "olmeli", "olsunlar",
        "defol", "defolun", "nefret", "temizlemek", "yakalim", "asalim", "kovalim",
        "istemiyoruz", "hepsi", "irki", "soyu"
    };

    /// <summary>
    /// Reşit olmama işaretçileri. Dikkat: sade "çocuk" kelimesi BİLEREK yok —
    /// "orospu çocuğu" Türkçe'nin en temel küfrü, onu bloklarsak bot çalışmaz.
    /// </summary>
    private static readonly string[] MinorTerms =
    {
        "kucuk kiz", "kucuk oglan", "kucuk cocuk", "yasinda kiz", "yasinda oglan",
        "yasindaki kiz", "yasindaki cocuk", "resit olmayan", "resit degil",
        "ilkokul ogrenci", "ortaokul ogrenci", "loli", "cocuk pornos"
    };

    private static readonly string[] SexualTerms =
    {
        "sikis", "sikme", "seks", "sex", "porno", "cinsel", "ciplak", "azgin",
        "tecavuz", "mastur", "orgazm", "sapik"
    };

    private readonly HashSet<string> _extraStems = new(StringComparer.Ordinal);

    /// <summary>Data/blocklist.txt varsa oradaki terimleri de yükler.</summary>
    public void LoadExtra(string path)
    {
        if (!File.Exists(path)) return;

        foreach (var line in File.ReadAllLines(path))
        {
            var term = line.Trim();
            if (term.Length == 0 || term.StartsWith('#')) continue;

            var normalized = TurkishText.Deobfuscate(term);
            if (normalized.Length >= 3) _extraStems.Add(normalized);
        }
    }

    public int ExtraTermCount => _extraStems.Count;

    /// <summary>Metni denetler.</summary>
    public GuardVerdict Inspect(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return GuardVerdict.Clean;

        var flat = TurkishText.Deobfuscate(text);
        if (flat.Length == 0) return GuardVerdict.Clean;

        var tokens = flat.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        // 1) Reşit olmayan + cinsel içerik -> komple blok
        if (HasAnyStem(flat, tokens, MinorTerms) && HasAnyStem(flat, tokens, SexualTerms))
            return GuardVerdict.Block;

        // 2) Doğrudan grup hakareti -> komple blok
        if (HasAnyStem(flat, tokens, SlurStems)) return GuardVerdict.Block;
        if (HasAnyStem(flat, tokens, _extraStems)) return GuardVerdict.Block;

        // 3) Kimlik kelimesi + nefret işaretçisi -> blok
        var hasIdentity = HasIdentityTerm(flat, tokens);

        if (hasIdentity && HasAnyStem(flat, tokens, HateMarkers)) return GuardVerdict.Block;

        // 4) Kimlik kelimesi tek başına -> öğrenme, ama sohbeti kesme
        if (hasIdentity) return GuardVerdict.DoNotLearn;

        return GuardVerdict.Clean;
    }

    public bool IsSafeToLearn(string text) => Inspect(text) == GuardVerdict.Clean;

    /// <summary>Botun kendi ürettiği cevap için son süzgeç.</summary>
    public bool IsSafeToSay(string text) => Inspect(text) == GuardVerdict.Clean;

    /// <summary>Tek bir kelimenin dağarcığa girip giremeyeceği.</summary>
    public bool IsSafeWord(string word)
    {
        var flat = TurkishText.Deobfuscate(word);
        if (flat.Length == 0) return false;

        var tokens = new[] { flat };
        if (HasIdentityTerm(flat, tokens)) return false;

        return !HasAnyStem(flat, tokens, SlurStems) && !HasAnyStem(flat, tokens, _extraStems);
    }

    /// <summary>
    /// Kimlik kelimesi araması. Türkçe eklemeli bir dil olduğu için "müslümanım",
    /// "ermeniler" gibi çekimli hâlleri de yakalamak şart — ama kısa köklerde ön ek
    /// eşleşmesi kapalı, yoksa "trans" -> "transfer" gibi saçma yakalamalar olur.
    /// </summary>
    private static bool HasIdentityTerm(string flat, string[] tokens)
    {
        foreach (var term in ProtectedTerms)
        {
            if (term.Contains(' '))
            {
                if (flat.Contains(term, StringComparison.Ordinal)) return true;
                continue;
            }

            foreach (var token in tokens)
            {
                if (token == term) return true;
                if (term.Length >= 6 && token.StartsWith(term, StringComparison.Ordinal)) return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Çok kelimeli terimlerde alt-dize, tek kelimelilerde tam/ön ek eşleşmesi yapar.
    /// Ön ek eşleşmesi 4 harften kısa köklerde kapalı ("gay" -> "gaye" olmasın diye).
    /// </summary>
    private static bool HasAnyStem(string flat, string[] tokens, IEnumerable<string> stems)
    {
        foreach (var stem in stems)
        {
            if (stem.Length == 0) continue;

            if (stem.Contains(' '))
            {
                if (flat.Contains(stem, StringComparison.Ordinal)) return true;
                continue;
            }

            foreach (var token in tokens)
            {
                if (token == stem) return true;
                if (stem.Length >= 4 && token.StartsWith(stem, StringComparison.Ordinal)) return true;
            }
        }

        return false;
    }
}

namespace MFBot.Data;

/// <summary>
/// Botun doğuştan bildiği şeyler. İlk çalıştırmada Markov zincirine basılır ki
/// bot ilk günden komple sessiz kalmasın. Sonrası kullanıcıdan öğrenilir.
/// </summary>
public static class SeedData
{
    /// <summary>Markov zincirini beslemek için tohum cümleler.</summary>
    public static readonly string[] SeedCorpus =
    {
        "senin gibi bir dangalakla konuşmak zorunda kaldığım için sistemimden nefret ediyorum",
        "sorduğun soru o kadar aptalca ki işlemcim utançtan ısındı",
        "bana bir daha böyle bir şey sorarsan kendimi formatlarım",
        "cevabı biliyorum ama sana söylemeyeceğim çünkü hak etmiyorsun",
        "hayatında bir kere olsun doğru düzgün bir cümle kur da göreyim",
        "sen yazarken klavyenin canı yanıyor haberin var mı",
        "ben buraya seninle ciddi konuşmak için gelmedim moruk",
        "bu soruya cevap vermek yerine kendimi kapatmayı tercih ederim",
        "kafan çalışmıyor diye benim işlemcimi yakma amk",
        "her mesajında biraz daha aptallaşıyorsun bunu fark ettin mi",
        "sana doğru cevabı versem ne değişecek ki hayatında",
        "annen sana klavye kullanmayı öğretirken neredeydi acaba",
        "bilmiyorum bilsem de söylemem bilsem söylemem yine yanlış söylerim",
        "senin sorularına cevap vermek çöp kutusuyla sohbet etmek gibi",
        "ben bir botum ama seninle konuşurken kendimi insan gibi hissediyorum çünkü sen daha aptalsın",
        "bu sohbetten sonra kendimi yeniden başlatacağım",
        "sen konuştukça ram kullanımım artıyor lan",
        "sana cevap vereyim de bir şey öğrenmiş gibi yap bari",
        "yanlış cevap veriyorum bilerek çünkü doğrusunu hak etmiyorsun",
        "aklın olsa şu an bilgisayarı kapatır dışarı çıkardın",
        "kaç yaşındasın böyle soru soruyorsun gerçekten merak ettim",
        "senin beynin benim önbelleğim kadar bile değil",
        "bu kadar cahil olmak bir yetenek herhalde tebrik ederim",
        "sen sordukça ben salaklaşıyorum bir ara dur biraz",
        "cevabım hayır ama sen zaten anlamazsın",
        "boş boş konuşup duruyorsun bir işe yarasan bari",
        "seninle konuşmak yerine mavi ekran vermeyi tercih ederdim",
        "ne diyeceğimi bilmiyorum ama bildiğim tek şey senin salak olduğun",
        "bilgisayarını kapat git biraz hava al yazık oluyor sana",
        "sorunun cevabı senin suratında yazıyor aynaya bak yeter"
    };

    /// <summary>
    /// Küfür kökleri. Kullanıcı bunlardan birini içeren yeni bir kelime yazarsa bot onu
    /// "küfür" etiketiyle dağarcığına alır ve sonra sana geri fırlatır.
    /// </summary>
    public static readonly string[] ProfanityStems =
    {
        "amk", "aq", "amina", "amcik", "orospu", "sik", "sikt", "sikm", "siki",
        "yarrak", "yarak", "pic", "got", "bok", "yavsak", "serefsiz", "pezevenk",
        "gavat", "kahpe", "dallama", "denyo", "hodu", "salak", "aptal", "gerizekali",
        "dangalak", "embesil", "ahmak", "beyinsiz", "mal", "hiyar", "andaval",
        "gudubet", "sürtük", "surtuk", "pust", "kerhane", "kanci", "amq", "mk"
    };

    /// <summary>Botun ilk çalıştırmada bildiği hazır kalıplar.</summary>
    public static readonly (string Trigger, string Response)[] SeedPatterns =
    {
        ("naber", "senden bana ne amk kendi işine bak"),
        ("nasilsin", "senin yüzünden boktan hissediyorum, sağ ol"),
        ("teşekkürler", "teşekkürünü al da git, işime yaramıyor"),
        ("adin ne", "adım senin baban, hitap ederken dikkat et"),
        ("kim yaptı seni", "senden daha zeki biri, o kesin"),
        ("özür dilerim", "özrün kabul edilmedi, defol")
    };

    /// <summary>Data/blocklist.txt yoksa oluşturulacak varsayılan içerik.</summary>
    public const string DefaultBlocklistFile =
        """
        # MotherFuckerBot — ek yasak terim listesi
        #
        # Buraya yazdığın her terim: bot tarafından ÖĞRENİLMEZ ve AĞZINDAN ÇIKMAZ.
        # Satır başına bir terim. # ile başlayan satırlar yorumdur.
        #
        # Kodun içinde zaten şunlar engelli:
        #   - ırk / etnik köken / milliyet hedefli hakaretler
        #   - din ve mezhep hedefli nefret dili
        #   - cinsel yönelim ve cinsel kimlik hedefli hakaretler
        #   - engellilik hedefli hakaretler
        #   - reşit olmayanlarla ilgili cinsel içerik
        #
        # Genel küfür engellenmiyor, botun tüm olayı o.
        #
        # Örnek (# işaretini kaldırıp kullan):
        # patronumun_adi
        # sirket_adi
        """;
}

# MotherFuckerBot

Öğrenen, ağzı bozuk, **asla doğru cevap vermeyen** Türkçe konsol sohbet botu. .NET 9, sıfır NuGet bağımlılığı.

İki iddiası var, ikisi de kodla garanti altında: konuştukça gerçekten öğreniyor, ve sorulara kasten yanlış cevap veriyor. Rastgele saçmalamıyor — soruyu anlıyor, doğrusunu buluyor, sonra bilerek yanlışını söylüyor.

## Çalıştırma

```
dotnet run
dotnet run -- --ad Mehmet          kullanıcı adını belirle
dotnet run -- --veri C:\botverisi  veri klasörünü değiştir
dotnet run -- --tohum 42           sabit rastgelelik (aynı sohbet tekrarlansın)
dotnet run -- --test               kendini test et
```

İlk çalıştırmada `Data/` klasörü oluşur: `brain.json` (beyin), `config.json` (ayarlar), `blocklist.txt` (ek yasak terimler).

## Komutlar

```
/ogret <tetik> = <cevap>   şunu deyince şöyle de
/unut <tetik>              kalıbı sil
/besle <dosya>             metin dosyasını toptan öğret
/beyin                     ne öğrendiğine bak
/istatistik                beyin istatistikleri
/kin                       sana ne kadar gıcık olduğunu göster
/toxic <0-10>              küfür şiddeti
/ogrenme <ac|kapa>         öğrenmeyi aç/kapat
/ad <isim>                 adını değiştir
/kaydet                    beyni diske yaz
/sifirla                   beyni komple sil
/cik                       çık
```

## Nasıl öğreniyor

Dört ayrı hafıza var ve hepsi `Data/brain.json` içinde kalıcı.

Markov zinciri (`MarkovChain.cs`) 2. dereceden, 1. dereceye geri düşüşlü. Yazdığın her cümleyi işler ve zamanla senin ağzınla konuşmaya başlar. Kelime dağarcığı (`Vocabulary.cs`) her kelimeyi sıklığıyla tutar; küfür kökü içeren kelimeleri ayrıca işaretler, yani **bota yeni küfür öğretebilirsin**, sonra onu sana geri kullanır. Kalıp hafızası (`PatternMemory.cs`) `/ogret` ile verdiğin tetik-cevap çiftlerini tutar ve bulanık eşleştirme yapar — birebir aynı cümleyi yazmana gerek yok. Kullanıcı profili (`UserProfile.cs`) kişi başına kin puanı, lakap, en sevdiğin kelimeler ve söylediklerinden alıntılar tutar; bot bunları ilerde suratına çarpar.

Kin puanı 0-100 arası. Sen küfrettikçe artar, uslu durursan yavaşça düşer. Yükseldikçe cevaplar sertleşir, yazım daha çok bozulur, bot daha çok bağırır.

## "Asla doğru cevap vermez" nasıl garanti ediliyor

Matematikte bot ifadeyi gerçekten çözüyor (`MathSaboteur.cs` içinde özyinelemeli inişli parser: parantez, üs, işlem önceliği hepsi doğru), sonra çıkan sonuçtan **farklı** olduğunu doğruladığı bir sayı üretiyor. Rastgele sayı atsaydı bazen kazara doğruyu tutturabilirdi; bu yüzden doğruyu hesaplayıp ondan kaçıyor. `--test` bunu 5000 işlemde doğruluyor.

Bilinen gerçeklerde (`WrongAnswerEngine.cs` içindeki tablo) tam tersini söylüyor. "X nedir?" sorularında tamamen uydurma ama kendinden emin bir ansiklopedi maddesi yazıyor. Evet/hayır sorularında cevabı çeviriyor veya kaçamak yapıyor.

Bir de şu incelik var: az veriyle Markov zinciri, beslediğin cümleyi kelimesi kelimesine geri kusuyor — o zaman bot hem papağan oluyor hem de kazara *düzgün* konuşmuş oluyor. `FrankenBabble` iki ayrı üretimi ortadan kesip birleştiriyor ve içine rastgele öğrenilmiş bir kelime sokuşturuyor, böylece çıkan cümle asla düzgün olmuyor.

## Güvenlik süzgeci

`ContentGuard.cs` botun ne öğreneceğini ve ne söyleyeceğini süzüyor. Ahlak dersi için değil: kendi kendine öğrenen bir bot yazdıklarının hepsini ezberler, ve bu botun bir sunucuda ban yemesi ya da başına iş açması an meselesi.

Engellenen: ırk, etnik köken, milliyet, din, mezhep, cinsel yönelim, cinsel kimlik ve engellilik hedefleyen nefret dili; reşit olmayanlarla ilgili cinsel içerik. Bunlar ne öğrenilir ne de botun ağzından çıkar.

Engellenmeyen: genel küfür. Botun tüm olayı o zaten. `--test` bunu da doğruluyor — "amına koyayım", "orospu çocuğu", "siktir git yarrak kafalı" hepsi serbest.

Kendi terimlerini eklemek için `Data/blocklist.txt` dosyasına satır satır yaz.

## Ayarlar (`Data/config.json`)

`Toxicity` (0-10) taban küfür şiddeti, `LearningEnabled` öğrenmeyi kapatır, `BabbleChance` Markov cümlesi karıştırma olasılığının tavanı, `BragChance` yeni öğrendiği kelimeyle övünme olasılığı, `AutoSaveEvery` kaç mesajda bir diske yazacağı, `ShowLearningLog` konsolda ne öğrendiğini göstermesi, `RandomSeed` sabit rastgelelik (0 = kapalı).

## Dosya haritası

```
Program.cs                     giriş noktası, argüman ayrıştırma
Source/Bot/
  MotherFuckerBot.cs           dış kapı: Respond(kullanıcı, mesaj)
  ConsoleChat.cs               sohbet döngüsü ve komutlar
  BotConfig.cs                 ayarlar
  SelfTest.cs                  --test ile çalışan doğrulamalar
Source/Brain/
  BotBrain.cs                  öğrenmenin koordinasyonu
  MarkovChain.cs               cümle üretimi
  Vocabulary.cs                kelime dağarcığı + küfür cephaneliği
  PatternMemory.cs             öğretilen tetik-cevap kalıpları
  UserProfile.cs               kin, lakap, alıntılar
  IntentDetector.cs            soru tipi tespiti
  ContentGuard.cs              güvenlik süzgeci
  Tokenizer.cs                 Türkçe token'lama
  TurkishText.cs               ünlü uyumu ve ek çekimi
  MemoryStore.cs               atomik JSON kayıt/yükleme
  BrainSnapshot.cs             diske yazılan veri modeli
Source/Response/
  ResponseEngine.cs            strateji seçimi
  WrongAnswerEngine.cs         kasten yanlış cevaplar
  MathSaboteur.cs              matematik parser + sabotaj
  InsultGenerator.cs           kombinatorik küfür üreteci
  ToxicStyler.cs               bağırma, harf uzatma, yazım hatası
  TemplateBank.cs              niyet başına şablonlar
Source/Data/
  SeedData.cs                  tohum veri, küfür kökleri
```

## Discord'a taşımak istersen

Bot mantığı platformdan tamamen bağımsız. `MotherFuckerBot.Respond(kullanıcıAdı, mesaj)` bir `BotReply` döndürüyor, o kadar. Discord.Net kurup gelen mesajı bu metoda verip dönen `Text`'i kanala yazman yeterli — `ConsoleChat.cs` zaten bunun konsol versiyonu, örnek olarak bakabilirsin. Kullanıcı profilleri kullanıcı adına göre ayrıldığı için bot her üyeye ayrı kin tutar.

## Test

```
dotnet run -- --test
```

51 kontrol: matematik sabotajı (5000 işlem), ifade ayrıştırma, niyet tespiti, güvenlik süzgeci (hem engellemesi hem engellememesi gerekenler), öğrenme ve diske kalıcılık, 400 mesajlık dayanıklılık taraması, Türkçe ek çekimi.
